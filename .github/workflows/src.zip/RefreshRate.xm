#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/message.h>
#import <CPUthermalPaths.h>

#define CPUTHERMAL_TARGET_FPS 120.0

static BOOL gForce120Hz = NO;

@interface CADisplay : NSObject
+ (id)mainDisplay;
- (NSArray *)availableModes;
- (void)setPreferences:(id)preferences;
@end
@interface CADisplayPreferences : NSObject
- (void)setPreferredRefreshRate:(double)rate;
@end
@interface CAMutableDisplayPreferences : CADisplayPreferences @end
@interface CADynamicFrameRateSource : NSObject
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range;
- (CAFrameRateRange)preferredFrameRateRange;
@end
@interface CAFrameRateRangeGroup : NSObject
- (CAFrameRateRange)arbitratedRange;
@end

static BOOL CPUthermalDeviceSupports120Hz(void) {
    static int cached = -1;
    if (cached >= 0) return cached == 1;
    cached = 0;
    @try {
        Class displayClass = NSClassFromString(S("CADisplay"));
        SEL mainSelector = NSSelectorFromString(S("mainDisplay"));
        id display = [displayClass respondsToSelector:mainSelector] ? ((id (*)(id, SEL))objc_msgSend)(displayClass, mainSelector) : nil;
        SEL modesSelector = NSSelectorFromString(S("availableModes"));
        NSArray *modes = [display respondsToSelector:modesSelector] ? ((id (*)(id, SEL))objc_msgSend)(display, modesSelector) : nil;
        for (id mode in modes) {
            id value = [mode valueForKey:S("refreshRate")];
            if ([value doubleValue] >= 119.0) { cached = 1; break; }
        }
        if (!cached && [UIScreen mainScreen].maximumFramesPerSecond >= 120) cached = 1;
    } @catch (__unused NSException *exception) {}
    return cached == 1;
}

// 温度保护已移除：只按开关与设备能力决定是否强制 120Hz。
static BOOL CPUthermalShouldForce120Hz(void) {
    return gForce120Hz && CPUthermalDeviceSupports120Hz();
}

static CAFrameRateRange CPUthermalForcedRange(CAFrameRateRange original, BOOL fixedMinimum) {
    CAFrameRateRange range = original;
    range.minimum = fixedMinimum ? 120.0f : ((original.minimum > 0 && original.minimum <= 120.0f) ? original.minimum : 10.0f);
    range.maximum = 120.0f;
    range.preferred = 120.0f;
    return range;
}

static void CPUthermalApplyDisplayLink(CADisplayLink *link) {
    if (!link || !CPUthermalShouldForce120Hz()) return;
    link.preferredFrameRateRange = CAFrameRateRangeMake(10, 120, 120);
}

@interface CPUthermalRefreshDriver : NSObject
@property(nonatomic,strong) CADisplayLink *persistentLink;
@property(nonatomic,strong) NSTimer *thermalTimer;
+ (instancetype)sharedInstance;
- (void)reloadAndApply;
@end
@implementation CPUthermalRefreshDriver
+ (instancetype)sharedInstance { static id value; static dispatch_once_t once; dispatch_once(&once, ^{ value=[self new]; }); return value; }
- (instancetype)init { if((self=[super init])) _thermalTimer=[NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(thermalTick:) userInfo:nil repeats:YES]; return self; }
- (void)persistentTick:(CADisplayLink *)link { (void)link; }
- (void)thermalTick:(NSTimer *)timer { (void)timer; [self reloadAndApply]; }
- (void)reloadAndApply {
    BOOL active=CPUthermalShouldForce120Hz();
    if(gForce120Hz && !self.persistentLink){ self.persistentLink=[CADisplayLink displayLinkWithTarget:self selector:@selector(persistentTick:)]; [self.persistentLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes]; }
    self.persistentLink.paused=!active;
    if(active) CPUthermalApplyDisplayLink(self.persistentLink);
}
@end

%hook UIScreen
- (NSInteger)maximumFramesPerSecond {
    if (CPUthermalShouldForce120Hz()) return 120;
    return %orig;
}
%end

%hook CADisplayLink
+ (CADisplayLink *)displayLinkWithTarget:(id)target selector:(SEL)selector {
    CADisplayLink *link = %orig;
    CPUthermalApplyDisplayLink(link);
    return link;
}
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
    if (CPUthermalShouldForce120Hz()) {
        CAFrameRateRange forced = CPUthermalForcedRange(range, NO);
        %orig(forced);
    } else {
        %orig(range);
    }
}
- (void)setPreferredFramesPerSecond:(NSInteger)fps {
    if (CPUthermalShouldForce120Hz()) {
        %orig(0);
    } else {
        %orig(fps);
    }
}
- (void)setFrameInterval:(NSInteger)interval {
    if (CPUthermalShouldForce120Hz()) {
        %orig(1);
    } else {
        %orig(interval);
    }
}
%end

%hook CAMutableDisplayPreferences
- (void)setPreferredRefreshRate:(double)rate {
    double target = CPUthermalShouldForce120Hz() ? 120.0 : rate;
    %orig(target);
}
%end
%hook CADisplayPreferences
- (void)setPreferredRefreshRate:(double)rate {
    double target = CPUthermalShouldForce120Hz() ? 120.0 : rate;
    %orig(target);
}
%end
%hook CADisplay
- (void)setPreferences:(id)preferences {
    if(CPUthermalShouldForce120Hz() && preferences) @try { [preferences setValue:@120.0 forKey:S("preferredRefreshRate")]; } @catch(__unused NSException *e) {}
    %orig(preferences);
}
%end

%hook CAContext
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
    if (CPUthermalShouldForce120Hz()) {
        CAFrameRateRange forced = CPUthermalForcedRange(range, NO);
        %orig(forced);
    } else {
        %orig(range);
    }
}
- (void)setPreferredFrameRate:(float)rate {
    float target = (CPUthermalShouldForce120Hz() && rate >= 60.0f) ? 120.0f : rate;
    %orig(target);
}
%end

%hook CADynamicFrameRateSource
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range {
    if (CPUthermalShouldForce120Hz()) {
        CAFrameRateRange forced = CPUthermalForcedRange(range, YES);
        %orig(forced);
    } else {
        %orig(range);
    }
}
- (CAFrameRateRange)preferredFrameRateRange {
    CAFrameRateRange range = %orig;
    if (CPUthermalShouldForce120Hz()) return CPUthermalForcedRange(range, YES);
    return range;
}
%end

%hook CAFrameRateRangeGroup
- (CAFrameRateRange)arbitratedRange {
    CAFrameRateRange range = %orig;
    if (CPUthermalShouldForce120Hz()) return CPUthermalForcedRange(range, YES);
    return range;
}
%end

static void CPUthermalReloadRefreshPrefs(void) {
    BOOL force120=NO, protection=YES;
    if (!CPUthermalReadRefreshRateState(&force120, &protection)) {
        NSDictionary *prefs=CPUthermalReadPrefs()?:@{};
        force120=NO; // 已移除
        // 不再读取温度保护键；状态高位固定为 0 以兼容旧面板。
        CPUthermalPostRefreshRateState(force120, NO);
    }
    gForce120Hz=force120;
    dispatch_async(dispatch_get_main_queue(), ^{ [[CPUthermalRefreshDriver sharedInstance] reloadAndApply]; });
}
static void CPUthermalRefreshPrefsChanged(CFNotificationCenterRef c,void *o,CFNotificationName n,const void *x,CFDictionaryRef u){ CPUthermalReloadRefreshPrefs(); }

%ctor {
    @autoreleasepool {
        CPUthermalReloadRefreshPrefs();
        CFNotificationCenterRef center=CFNotificationCenterGetDarwinNotifyCenter();
        CFNotificationCenterAddObserver(center,NULL,CPUthermalRefreshPrefsChanged,(__bridge CFStringRef)S(kCPUthermalSettingsChangedNotifC),NULL,CFNotificationSuspensionBehaviorDeliverImmediately);
        CFNotificationCenterAddObserver(center,NULL,CPUthermalRefreshPrefsChanged,(__bridge CFStringRef)S(kCPUthermalRefreshRateNotifC),NULL,CFNotificationSuspensionBehaviorDeliverImmediately);
    }
}
