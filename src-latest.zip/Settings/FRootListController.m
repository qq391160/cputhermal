#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <spawn.h>
#import <sys/wait.h>
#import <notify.h>
#import <dlfcn.h>
#import <CPUthermalPaths.h>

// ============================================================
// 注意: 禁止使用 @"" ObjC 字符串常量
// roothide 重映射会破坏 __cfstring 内部指针，导致 SIGBUS
// 所有字符串通过 C 字符串 + stringWithUTF8String: 动态创建
// ============================================================

@interface FRootListController : PSListController
@end

@implementation FRootListController

- (NSString *)prefPath {
    return CPUthermalCurrentPrefPath();
}

- (NSString *)legacyPrefPath {
    NSArray<NSString *> *paths = CPUthermalLegacyPrefPaths();
    return paths.count > 0 ? paths[0] : nil;
}

- (void)ensurePrefsDirectory {
    NSString *directory = [[self prefPath] stringByDeletingLastPathComponent];
    [[NSFileManager defaultManager] createDirectoryAtPath:directory
                                withIntermediateDirectories:YES
                                                 attributes:nil
                                                      error:nil];
}

- (void)purgeRemovedFeaturePrefs {
    // 清理已删除功能遗留的配置键：避免旧值在插件里“复活”或与新逻辑冲突
    NSMutableDictionary *prefs = [self prefs];
    if (!prefs.count) return;
    NSArray *dead = [NSArray arrayWithObjects:
        S("simulateMaximumCapacity"), S("suppressBatteryServiceWarnings"),
        S("smartChargeEnabled"), S("smartChargeUseSmartBatteryAPI"),
        S("smartChargeDisableInflow"), S("smartChargeStopLevel"),
        S("__smartChargeOwnsInhibit"), S("__smartChargeOwnsInflowDisable"),
        S("__smartChargeOwnershipPreferSmart"),
        S("forceFastChargeEnabled"), S("killThermalStopCharging"),
        S("force120HzEnable"), S("highPerformanceModeEnabled"), nil];
    BOOL changed = NO;
    for (NSString *k in dead) {
        if (prefs[k]) { [prefs removeObjectForKey:k]; changed = YES; }
    }
    if (changed) CPUthermalWritePrefs(prefs);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self purgeRemovedFeaturePrefs];
}

- (NSMutableDictionary *)prefs {
    NSMutableDictionary *d = CPUthermalReadMutablePrefs();
    if (!d) d = [NSMutableDictionary dictionary];
    return d;
}

- (void)runThermalToolCommand:(const char *)command value:(BOOL)value hasValue:(BOOL)hasValue {
    NSString *toolPath = CPUthermalToolPath();
    if (!toolPath.length || !command) return;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        pid_t pid = 0;
        char valueBuffer[2] = { value ? '1' : '0', '\0' };
        char *argsWithValue[] = {(char *)"CPUthermalTool", (char *)command, valueBuffer, NULL};
        char *argsNoValue[] = {(char *)"CPUthermalTool", (char *)command, NULL};
        char **arguments = hasValue ? argsWithValue : argsNoValue;
        if (posix_spawn(&pid, toolPath.fileSystemRepresentation, NULL, NULL, arguments, NULL) == 0) waitpid(pid, NULL, 0);
    });
}

- (void)restartThermalMonitorImmediately {
    NSString *client = CPUthermalExistingExecutablePath("/usr/local/bin/CPUthermalMountClient", @[
        S("/var/jb/usr/local/bin/CPUthermalMountClient"), S("/usr/local/bin/CPUthermalMountClient")]);
    if (!client.length) return;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        pid_t pid = 0;
        char *args[] = {(char *)"CPUthermalMountClient", (char *)"restart-thermal-monitor", NULL};
        posix_spawn(&pid, client.fileSystemRepresentation, NULL, NULL, args, NULL);
    });
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    if (!key) return;

    NSMutableDictionary *prefs = [self prefs];

    // 功率模式统一规范为字符串，防止框架传入 NSNumber 索引
    if ([key isEqualToString:S("powerMode")]) {
        if ([value isKindOfClass:[NSNumber class]]) {
            value = ([value intValue] == 0) ? S("lowPower") : S("fullPower");
        } else if (![value isKindOfClass:[NSString class]]) {
            value = S("fullPower");
        }
    }

    prefs[key] = value;
    if ([key isEqualToString:S("sunlightLockedEnabled")]) {
        [prefs removeObjectForKey:S("sunlightAutomatic")];
        [prefs removeObjectForKey:S("sunlightOverride")];
    }
    if ([key isEqualToString:S("hipLockedEnabled")]) {
        [prefs removeObjectForKey:S("hipProtectionEnabled")];
        [prefs removeObjectForKey:S("simulateHIP")];
        [prefs removeObjectForKey:S("hipLockedMode")];
    }
    CPUthermalWritePrefs(prefs);
    if ([key isEqualToString:S("hipLockedEnabled")]) {
        // 设置页为亮屏：固定“仅锁屏”时立即恢复原生；锁屏后由 thermalmonitord 自动启用。
        [self runThermalToolCommand:"hip-lock" value:NO hasValue:YES];
    } else if ([key isEqualToString:S("sunlightLockedEnabled")]) {
        if ([value boolValue]) [self runThermalToolCommand:"sunlight-override" value:YES hasValue:YES];
        else [self runThermalToolCommand:"sunlight-auto" value:NO hasValue:NO];
    }

    // 功率模式只发专用通知，避免 settingsChanged + powerModeChanged 重复应用。
    if ([key isEqualToString:S("powerMode")]) {
        // 软切换即可；重启 thermalmonitord 会杀掉亮度恢复任务并遗留 DCP 暗屏 cap。
        CPUthermalPostPowerMode(value);
        // 主面板的说明文字跟着常驻模式变，切换后立即刷新
        [self applyModeAwareFooters];
        _specifiers = nil;
        [self reloadSpecifiers];
    } else {
        notify_post(kCPUthermalSettingsChangedNotifC);
    }
}

- (id)readPreferenceValue:(PSSpecifier *)spec {
    NSString *key = [spec propertyForKey:S("key")];
    if (!key) return nil;
    
    // 功率模式为字符串值，默认满血(解除温控)
    if ([key isEqualToString:S("powerMode")]) {
        id mode = [self prefs][key];
        if (mode && [mode isKindOfClass:[NSString class]]) return mode;
        return S("fullPower");
    }
    
    
    id val = [self prefs][key];
    if (val) return val;

    // 其余功能开关默认关闭，仅用户主动开启后生效。
    return [NSNumber numberWithBool:NO];
}

#pragma mark - 工具方法

- (void)openURLString:(NSString *)urlString fallback:(NSString *)fallbackURL failureMessage:(NSString *)failureMessage {
    NSURL *url = [NSURL URLWithString:urlString];
    if (!url) return;

    [[UIApplication sharedApplication] openURL:url
                                       options:[NSDictionary dictionary]
                             completionHandler:^(BOOL success) {
        if (success) return;
        if (fallbackURL) {
            NSURL *fallback = [NSURL URLWithString:fallbackURL];
            if (fallback) {
                [[UIApplication sharedApplication] openURL:fallback options:[NSDictionary dictionary] completionHandler:nil];
                return;
            }
        }
        if (failureMessage) {
            [self showSimpleAlertWithTitle:S("提示") message:failureMessage];
        }
    }];
}

- (void)showSimpleAlertWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:title
        message:message
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:S("好的") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - 重启用户空间

- (void)usreboot {
    UIAlertController *alert = [UIAlertController
        alertControllerWithTitle:S("重启用户空间")
        message:S("安装或升级时只会自动重启 thermalmonitord；此操作将重启 SpringBoard 和其他用户态服务。")
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:S("取消")
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:S("确定重启")
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *action) {
        pid_t pid = 0;
        NSString *toolPath = CPUthermalToolPath();
        if (toolPath.length > 0 && [[NSFileManager defaultManager] isExecutableFileAtPath:toolPath]) {
            char *args[] = {(char *)"CPUthermalTool", (char *)"userspace-reboot", NULL};
            if (posix_spawn(&pid, [toolPath fileSystemRepresentation], NULL, NULL, args, NULL) == 0) {
                waitpid(pid, NULL, 0);
                return;
            }
        }

        NSString *launchctlPath = CPUthermalLaunchctlPath();
        if (launchctlPath.length == 0) return;
        char *args[] = {(char *)"launchctl", (char *)"reboot", (char *)"userspace", NULL};
        if (posix_spawn(&pid, [launchctlPath fileSystemRepresentation], NULL, NULL, args, NULL) == 0) {
            waitpid(pid, NULL, 0);
        }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - 开源代码

- (void)openSourceCode {
    [self openURLString:S("https://github.com/be-huge/insulation") fallback:nil failureMessage:S("无法打开 GitHub，请手动访问 https://github.com/be-huge/insulation")];
}

//==============================================================================
#pragma mark - 主面板说明随当前常驻模式动态生成
//==============================================================================

- (void)applyModeAwareFooters {
    id mode = [self prefs][S("powerMode")];
    BOOL residentLowPower = [mode isKindOfClass:[NSString class]] && [mode isEqualToString:S(kCPUthermalLowPowerModeC)];
    for (PSSpecifier *specifier in _specifiers) {
        NSString *label = [specifier propertyForKey:S("label")];
        if (![label isKindOfClass:[NSString class]]) continue;
        NSString *footer = nil;
        if ([label hasPrefix:S("指定 App 满频率")]) {
            footer = residentLowPower
                ? S("▼ 当前生效。常驻「低功耗」时：勾选的应用进入后满频运行（不卡），其它应用保持低功耗；熄屏时一律低功耗。点进去可「全选」。")
                : S("当前常驻是「解除温控」—— 这份名单不参与调度，只在常驻「低功耗」时用于指定满频应用。点进去可「全选」。");
        } else if ([label hasPrefix:S("指定 App 低频率")]) {
            footer = residentLowPower
                ? S("当前常驻是「低功耗」—— 这份名单不参与调度，只在常驻「解除温控」时用于指定低功耗应用。点进去可「全选」。")
                : S("▼ 当前生效。常驻「解除温控」时：勾选的应用进入后执行低功耗（省电），其它应用满频。点进去可「全选」。");
        } else if ([label isEqualToString:S("低功耗模式")]) {
            footer = residentLowPower
                ? S("▼ 当前生效（常驻「低功耗」）：功率预算、高温自动保护，以及「指定 App 满频率」名单。")
                : S("当前常驻是「解除温控」—— 本组只在常驻「低功耗」时参与调度。");
        } else if ([label isEqualToString:S("解除温控模式")]) {
            footer = residentLowPower
                ? S("当前常驻是「低功耗」—— 本组只在常驻「解除温控」时参与调度。")
                : S("▼ 当前生效（常驻「解除温控」）：满频策略、对抗温控限制，以及「指定 App 低频率」名单。");
        }
        if (footer) {
            [specifier setProperty:footer forKey:S("footerText")];
        }
    }
}

#pragma mark - Specifier 加载

- (NSArray *)specifiers {
    if (!_specifiers) {
        // 直接从 Root.plist 加载配置结构，Preferences 框架会自动正确解析 PSSegmentCell
        _specifiers = [self loadSpecifiersFromPlistName:S("Root") target:self];
        [self applyModeAwareFooters];
    }
    return _specifiers;
}

@end
