#import "ctdefer.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <notify.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <CPUthermalPaths.h>

static NSString *CPUthermalOwnBundleID(void) {
    return [[NSBundle mainBundle] bundleIdentifier];
}

static NSString *CPUthermalStringFromObject(id object, const char **selectors) {
    for (int i = 0; object && selectors[i]; i++) {
        SEL selector = sel_registerName(selectors[i]);
        if (![object respondsToSelector:selector]) continue;
        id value = ((id (*)(id, SEL))objc_msgSend)(object, selector);
        if ([value isKindOfClass:[NSString class]] && [value length] > 0) return value;
    }
    return nil;
}

static void CPUthermalReportCurrentApplication(void) {
    UIApplication *application = [UIApplication sharedApplication];
    if (application.applicationState != UIApplicationStateActive) return;
    CPUthermalPostForegroundBundleID(CPUthermalOwnBundleID());
}

static void CPUthermalClearCurrentApplication(void) {
    CPUthermalClearForegroundBundleIDIfCurrent(CPUthermalOwnBundleID());
}

// 由 SBApplication activate/deactivate 维护的"当前激活应用"，作为私有接口失效时的兜底真值源。
static NSString *g_trackedFrontmostBundleID = nil;

// ★ 解锁瞬间防丢：锁屏期间记住"上一个真正的 App"，解锁后几秒内若前台被报成锁屏/桌面，先用它顶上。
//   否则会被误判成"退出了名单 App" → 撤销低功耗 → 一直等到 2~4 秒后 SpringBoard 才交回真实 App。
static NSString *g_ctLastRealAppBundleID = nil;
static CFAbsoluteTime g_ctUnlockStamp = 0;

static BOOL CPUthermalLockScreenVisible(void) {
    Class lsmClass = objc_getClass("SBLockScreenManager");
    SEL sharedSel = sel_registerName("sharedInstance");
    if (![lsmClass respondsToSelector:sharedSel]) return NO;
    id lsm = ((id (*)(id, SEL))objc_msgSend)(lsmClass, sharedSel);
    const char *visSel[] = {"isLockScreenVisible", "isLockScreenActive", "isUILocked", NULL};
    for (int i = 0; lsm && visSel[i]; i++) {
        SEL s = sel_registerName(visSel[i]);
        if ([lsm respondsToSelector:s]) return ((BOOL (*)(id, SEL))objc_msgSend)(lsm, s);
    }
    return NO;
}

// 部分 RootHide 注入配置会阻止目标应用加载通用 dylib；SpringBoard 作为系统级
// 真值源轮询当前前台应用，确保指定应用功能不依赖目标应用自身成功注入。
static NSString *CPUthermalSpringBoardFrontmostBundleID(void) {
    id springBoard = [UIApplication sharedApplication];
    id application = nil;
    const char *frontSelectors[] = {"_accessibilityFrontMostApplication", "accessibilityFrontMostApplication", "frontmostApplication", NULL};
    for (int i = 0; frontSelectors[i] && !application; i++) {
        SEL selector = sel_registerName(frontSelectors[i]);
        if ([springBoard respondsToSelector:selector]) application = ((id (*)(id, SEL))objc_msgSend)(springBoard, selector);
    }
    if (!application) {
        Class controllerClass = objc_getClass("SBApplicationController");
        SEL sharedSelector = sel_registerName("sharedInstance");
        id controller = [controllerClass respondsToSelector:sharedSelector] ? ((id (*)(id, SEL))objc_msgSend)(controllerClass, sharedSelector) : nil;
        SEL frontSelector = sel_registerName("frontmostApplication");
        if ([controller respondsToSelector:frontSelector]) application = ((id (*)(id, SEL))objc_msgSend)(controller, frontSelector);
    }
    if (!application) {
        // 再兜一层：SBWorkspace 在部分系统版本上持有前台应用。
        Class workspaceClass = objc_getClass("SBWorkspace");
        SEL mainSelector = sel_registerName("mainWorkspace");
        id workspace = [workspaceClass respondsToSelector:mainSelector] ? ((id (*)(id, SEL))objc_msgSend)(workspaceClass, mainSelector) : nil;
        SEL frontSelector = sel_registerName("frontmostApplication");
        if ([workspace respondsToSelector:frontSelector]) application = ((id (*)(id, SEL))objc_msgSend)(workspace, frontSelector);
    }
    const char *idSelectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    NSString *identifier = CPUthermalStringFromObject(application, idSelectors);
    if (identifier.length) return identifier;
    // 私有接口全部取不到时，退回 activate/deactivate 维护的当前应用，避免上报 nil→0。
    return g_trackedFrontmostBundleID;
}

// 多任务（卡片）界面是 SpringBoard 的浮层，此时 App 仍算"前台"但用户并没有在用。
// 命中多种可能的私有接口，全部取不到就返回 NO，保持原有行为。
static BOOL CPUthermalAppSwitcherVisible(void) {
    SEL sharedSelector = sel_registerName("sharedInstance");
    Class coordinatorClass = objc_getClass("SBMainSwitcherControllerCoordinator");
    if ([coordinatorClass respondsToSelector:sharedSelector]) {
        id coordinator = ((id (*)(id, SEL))objc_msgSend)(coordinatorClass, sharedSelector);
        const char *selectors[] = {"isAnySwitcherVisible", "hasAnySwitcherVisible", "isSwitcherVisible", NULL};
        for (int i = 0; coordinator && selectors[i]; i++) {
            SEL selector = sel_registerName(selectors[i]);
            if ([coordinator respondsToSelector:selector]) return ((BOOL (*)(id, SEL))objc_msgSend)(coordinator, selector);
        }
    }
    Class controllerClass = objc_getClass("SBAppSwitcherController");
    if ([controllerClass respondsToSelector:sharedSelector]) {
        id controller = ((id (*)(id, SEL))objc_msgSend)(controllerClass, sharedSelector);
        const char *selectors[] = {"isMainSwitcherVisible", "isVisible", "_isVisible", NULL};
        for (int i = 0; controller && selectors[i]; i++) {
            SEL selector = sel_registerName(selectors[i]);
            if ([controller respondsToSelector:selector]) return ((BOOL (*)(id, SEL))objc_msgSend)(controller, selector);
        }
    }
    return NO;
}

static void CPUthermalStartSpringBoardMonitor(void) {
    __block uint64_t lastHash = UINT64_MAX;
    __block NSString *lastBundleID = nil;
    __block CFAbsoluteTime lastPost = 0;
    void (^poll)(void) = ^{
        // 卡片（多任务）界面：前台应用虽然还是它，但用户并没在使用 →
        // 立刻上报"无应用"，让 thermalmonitord 撤销低功耗，恢复满频。
        if (CPUthermalAppSwitcherVisible()) {
            if (lastBundleID.length || g_trackedFrontmostBundleID.length) {
                g_trackedFrontmostBundleID = nil;
                lastHash = 0;
                lastBundleID = nil;
                lastPost = CFAbsoluteTimeGetCurrent();
                CPUthermalPostForegroundBundleID(nil);
            }
            return;
        }
        NSString *bundleID = CPUthermalSpringBoardFrontmostBundleID();
        // ★★ 解锁回 App 时，私有接口常常仍返回"SpringBoard（锁屏界面）"——
        //    此时优先用 activate/deactivate 钩子跟踪到的当前 App（可靠通知链，用户实测"切一下 App 就对了"）。
        if (!bundleID.length || [bundleID isEqualToString:S("com.apple.springboard")]) {
            if (g_trackedFrontmostBundleID.length) bundleID = g_trackedFrontmostBundleID;
        }
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        if (!bundleID.length) {
            // ★ 锁屏/解锁瞬间系统常常"取不到前台"（返回空）—— 此时如果是锁屏界面或刚解锁，
            //   先用缓存的"上一个真实 App"顶上，避免被误判成"退出了名单 App"而撤销低功耗。
            if (g_ctLastRealAppBundleID.length) {
                BOOL withinUnlockWindow2 = (g_ctUnlockStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctUnlockStamp) < 6.0);
                if (CPUthermalLockScreenVisible() || withinUnlockWindow2) {
                    uint64_t h2 = CPUthermalBundleIDHash(g_ctLastRealAppBundleID);
                    if (h2 != lastHash || (CFAbsoluteTimeGetCurrent() - lastPost) >= 2.0) {
                        lastHash = h2;
                        lastBundleID = g_ctLastRealAppBundleID;
                        lastPost = CFAbsoluteTimeGetCurrent();
                        CPUthermalPostForegroundBundleID(g_ctLastRealAppBundleID);
                    }
                    return;
                }
            }
            // 取不到前台应用（私有接口偶发返回 nil，例如全屏视频/转场瞬间）时不能上报 0，
            // 否则 thermalmonitord 会误判为"已退出指定应用"并撤销低功耗。
            if (lastBundleID.length) {
                if (g_trackedFrontmostBundleID.length) {
                    // SpringBoard 侧仍认为该应用处于激活状态：沿用上次结果（心跳重发）。
                    if ([g_trackedFrontmostBundleID isEqualToString:lastBundleID] && (now - lastPost) >= 2.0) {
                        lastPost = now;
                        CPUthermalPostForegroundBundleID(lastBundleID);
                    }
                } else if ((now - lastPost) >= 1.5) {
                    // 前台应用已 deactivate（回桌面/真退出）：确认 1.5 秒后上报"无应用"，
                    // 让 thermalmonitord 侧的去抖逻辑正常收尾，避免一直卡在低功耗。
                    lastHash = 0;
                    lastBundleID = nil;
                    lastPost = now;
                    CPUthermalPostForegroundBundleID(nil);
                }
            }
            return;
        }
        BOOL isSpringBoard = [bundleID isEqualToString:S("com.apple.springboard")];
        if (bundleID.length && !isSpringBoard) {
            g_ctLastRealAppBundleID = bundleID;          // 记住真实 App
        } else if (bundleID.length && isSpringBoard && g_ctLastRealAppBundleID.length) {
            BOOL withinUnlockWindow = (g_ctUnlockStamp > 0 && (CFAbsoluteTimeGetCurrent() - g_ctUnlockStamp) < 6.0);
            if (CPUthermalLockScreenVisible() || withinUnlockWindow) {
                bundleID = g_ctLastRealAppBundleID;      // 顶上，避免误判"退出名单 App"
            }
        }
        uint64_t hash = CPUthermalBundleIDHash(bundleID);
        // 哈希变化立即上报；哈希不变时每 2 秒心跳重发一次，避免 thermalmonitord
        // 侧因通知丢失（进程重启、被唤醒逻辑覆盖等）长期停留在错误模式。
        BOOL heartbeat = (now - lastPost) >= 2.0;
        if (hash == lastHash && !heartbeat) return;
        lastHash = hash;
        lastBundleID = bundleID;
        lastPost = now;
        CPUthermalPostForegroundBundleID(bundleID);
    };
    static int ctLockToken = -1;
    notify_register_dispatch("com.apple.springboard.lockstate", &ctLockToken, dispatch_get_main_queue(), ^(int token) {
        uint64_t st = UINT64_MAX;
        if (notify_get_state(token, &st) == NOTIFY_STATUS_OK && st == 0) {
            g_ctUnlockStamp = CFAbsoluteTimeGetCurrent();
        }
    });
    poll();
    // 100ms 兜底轮询；应用激活 Hook 仍是主路径，RootHide 阻止目标 App 注入时也能快速识别。
    [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(__unused NSTimer *timer) { poll(); }];
}

@interface SBApplication : NSObject
- (NSString *)bundleIdentifier;
- (NSString *)displayIdentifier;
@end

%hook SBApplication
- (void)activate {
    const char *selectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    NSString *bundleID = CPUthermalStringFromObject(self, selectors);
    if (bundleID.length) g_trackedFrontmostBundleID = bundleID;
    // activate 前先发布，thermalmonitord 可与应用前台切换并行套用低功耗；完成后再确认一次。
    if (bundleID.length) CPUthermalPostForegroundBundleID(bundleID);
    %orig;
    if (bundleID.length) CPUthermalPostForegroundBundleID(bundleID);
}
- (void)deactivate {
    const char *selectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    NSString *bundleID = CPUthermalStringFromObject(self, selectors);
    if (bundleID.length && g_trackedFrontmostBundleID && [g_trackedFrontmostBundleID isEqualToString:bundleID]) {
        g_trackedFrontmostBundleID = nil;
    }
    %orig;
    // 退到桌面/切到别处时清掉状态（只有当前状态确实是它才会清），
    // 避免"回到桌面后仍被当作停留在指定应用"。
    if (bundleID.length) CPUthermalClearForegroundBundleIDIfCurrent(bundleID);
}
%end

%hook UIApplication
- (void)didBecomeActive {
    %orig;
    if (![CPUthermalOwnBundleID() isEqualToString:S("com.apple.springboard")]) CPUthermalReportCurrentApplication();
}
- (void)didEnterBackground {
    %orig;
    if (![CPUthermalOwnBundleID() isEqualToString:S("com.apple.springboard")]) CPUthermalClearCurrentApplication();
}
%end

%ctor {
    @autoreleasepool {
        NSString *ownBundleID = CPUthermalOwnBundleID();
        // 诊断：确认本进程是否真的载入 CPUthermalForeground.dylib（判定过滤器是否命中）。
        CTLOG(S("[CPUthermal] Foreground 载入 proc=%@ bundle=%@"), [[NSProcessInfo processInfo] processName], ownBundleID);
        CTDeferToMainRunLoop(^{
            if ([ownBundleID isEqualToString:S("com.apple.springboard")]) {
                CPUthermalStartSpringBoardMonitor();
                CTLOG(S("[CPUthermal] SpringBoard 前台监控已启动"));
                return;
            }
            NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
            [center addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) { CPUthermalReportCurrentApplication(); }];
            [center addObserverForName:UIApplicationWillEnterForegroundNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) {
                CTDeferToMainRunLoop(^{ CPUthermalReportCurrentApplication(); });
            }];
            [center addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) { CPUthermalClearCurrentApplication(); }];
            CPUthermalReportCurrentApplication();
        });
    }
}
