#ifndef CTDEFER_H
#define CTDEFER_H
#import <CoreFoundation/CoreFoundation.h>
// iOS17/dyld4 初始化阶段不能用 GCD（dispatch_async/once/source）→ 会 _Block_copy / _tlv_bootstrap(DYLD9) 崩。
// 第一次调用（构造期）：推迟到下一个主 runloop 迭代；之后再调用则立即同步执行。
static inline void CTDeferToMainRunLoop(void (^blk)(void)) {
    static BOOL ct_past_init = NO;
    if (ct_past_init) { blk(); return; }
    CFRunLoopRef rl = CFRunLoopGetMain();
    CFRunLoopPerformBlock(rl, kCFRunLoopCommonModes, ^{ ct_past_init = YES; blk(); });
    CFRunLoopWakeUp(rl);
}
#endif
