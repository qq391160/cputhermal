#import "CPUthermalCCModuleViewController.h"
#import <notify.h>
#import <Foundation/Foundation.h>
#import <spawn.h>
#import <CPUthermalPaths.h>

// ============================================================
// 注意: 禁止使用 @"" ObjC 字符串常量
// roothide 重映射会破坏 __cfstring 内部指针，导致 SIGBUS
// 所有字符串通过 C 字符串 + stringWithUTF8String: 动态创建
// ============================================================

@interface CPUthermalCCModuleViewController () {
    BOOL _lastInputWasTap;   // 上一次输入是否为“单击”，用于区分单击 / 长按
    BOOL _suppressNextTap;   // 长按后松手，避免被当成单击误切模式
    BOOL _longPressAttached; // 是否已给控件本体挂上长按识别
    BOOL _pendingModeMenu;   // 系统面板没展开时的兜底菜单
    BOOL _didExpand;         // 面板是否真的展开过（用于单击后自动收起）
}
- (void)updateSelectedIndexFromCurrentMode;
- (BOOL)isTweakEnabled;
- (void)saveTweakEnabled:(BOOL)enabled;
- (void)toggleTweakEnabled;
- (void)updateModuleSelectedState;
- (void)selectPowerModeAtIndex:(NSInteger)index;
- (void)selectPowerModeAtIndex:(NSInteger)index dismissAfterSelection:(BOOL)dismissAfterSelection;
- (CGFloat)availableExpandedContentWidth;
- (void)applyCompactMenuInsetsToLabel:(UILabel *)label inMenuItemView:(UIView *)menuItemView allowTwoLines:(BOOL)allowTwoLines;
- (void)styleMenuItemLabelsInView:(UIView *)view;
- (void)styleMenuItemLabelsAfterLayout;
- (BOOL)isModeTitle:(NSString *)text;
- (BOOL)isModeSubtitle:(NSString *)text;
- (UIView *)cpuTileButtonView;
- (void)setupTileLongPressIfNeeded;
- (void)handleTileLongPress:(UILongPressGestureRecognizer *)recognizer;
- (void)playHapticFeedback;
- (void)showModeMenu;
- (NSArray<UIViewController *> *)cpuPresentationHosts;
- (void)presentMenu:(UIAlertController *)menu hosts:(NSArray<UIViewController *> *)hosts index:(NSUInteger)index;
@end

static const CGFloat kCPUthermalCCPreferredExpandedWidth = 320.0;
static const CGFloat kCPUthermalCCPreferredExpandedHeight = 300.0;
static const CGFloat kCPUthermalCCMinimumScreenMargin = 30.0;
static const CGFloat kCPUthermalCCMenuLeadingInset = 18.0;
static const CGFloat kCPUthermalCCMenuTrailingInset = 46.0;
static const CGFloat kCPUthermalCCTitleFontSize = 15.0;
static const CGFloat kCPUthermalCCSubtitleFontSize = 11.0;

@interface UIView (CPUthermalCCPrivateLayout)
- (UILabel *)titleLabel;
- (UILabel *)subtitleLabel;
- (UIView *)contentView;
- (void)setUseTrailingCheckmarkLayout:(BOOL)useTrailingCheckmarkLayout;
- (void)setUseTrailingInset:(BOOL)useTrailingInset;
- (void)setIndentation:(CGFloat)indentation;
@end

@implementation CPUthermalCCModuleViewController

@synthesize modeValues = _modeValues;
@synthesize modeTitles = _modeTitles;
@synthesize modeSubtitles = _modeSubtitles;
@synthesize selectedIndex = _selectedIndex;

//==============================================================================
#pragma mark - Prefs Helpers
//==============================================================================


/// 读取当前功率模式值
- (NSString *)currentPowerMode {
    NSDictionary *prefs = CPUthermalReadPrefs();
    NSString *mode = prefs[S("powerMode")];
    if ([mode isKindOfClass:[NSString class]] && [mode length] > 0) {
        return mode;
    }
    return S(kCPUthermalFullPowerModeC); // 默认解除温控
}

- (BOOL)isTweakEnabled {
    return YES; // 始终启用，无需用户开关
}

- (void)saveTweakEnabled:(BOOL)enabled {
    // 已废弃：CPUthermal 始终启用，无需保存开关状态
}

/// 写入功率模式并发送通知
- (void)savePowerMode:(NSString *)mode {
    NSMutableDictionary *prefs = CPUthermalReadMutablePrefs();
    if (!prefs) prefs = [NSMutableDictionary dictionary];
    prefs[S("powerMode")] = mode ?: S(kCPUthermalFullPowerModeC);

    CPUthermalWritePrefs(prefs);
    CPUthermalPostPowerMode(mode ?: S(kCPUthermalFullPowerModeC));
    NSString *client = CPUthermalExistingExecutablePath("/usr/local/bin/CPUthermalMountClient", @[
        S("/var/jb/usr/local/bin/CPUthermalMountClient"), S("/usr/local/bin/CPUthermalMountClient")]);
    if (client.length) dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        pid_t pid = 0;
        char *args[] = {(char *)"CPUthermalMountClient", (char *)"restart-thermal-monitor", NULL};
        posix_spawn(&pid, client.fileSystemRepresentation, NULL, NULL, args, NULL);
    });
}


//==============================================================================
#pragma mark - Initialization
//==============================================================================

- (instancetype)init {
    self = [super init];
    if (self) {
        _modeValues = @[S(kCPUthermalLowPowerModeC), S(kCPUthermalFullPowerModeC)];
        _modeTitles = @[S("低功耗"), S("解除温控")];
        _modeSubtitles = @[S("更省电，机身更凉，可选择指定 APP 满频率"), S("性能优先，全部满频，可选择指定 APP 低功耗")];

        // 读取当前设置的模式
        NSString *currentMode = [self currentPowerMode];
        _selectedIndex = [_modeValues indexOfObject:currentMode];
        if (_selectedIndex == NSNotFound) {
            _selectedIndex = [_modeValues indexOfObject:S(kCPUthermalFullPowerModeC)];
        }
    }
    return self;
}

//==============================================================================
#pragma mark - UIViewController Lifecycle
//==============================================================================

// 生成“符号 + 文字”的小图标，尺寸对齐系统图标，模板渲染 → 自动跟随浅色/深色变黑或变白
// 低功耗 = 🐢 +「低功耗」   解除温控 = 🐰 +「满频」
- (UIImage *)labeledGlyphForLowPower:(BOOL)lowPower {
    NSString *symbolName = lowPower ? S("tortoise.fill") : S("hare.fill");
    NSString *text = lowPower ? S("低功耗") : S("满频");

    UIImageSymbolConfiguration *config =
        [UIImageSymbolConfiguration configurationWithPointSize:20 weight:UIImageSymbolWeightRegular];
    UIImage *symbol = [UIImage systemImageNamed:symbolName withConfiguration:config];
    CGSize symbolSize = symbol ? symbol.size : CGSizeZero;

    NSDictionary *attrs = @{ NSFontAttributeName: [UIFont systemFontOfSize:10.0 weight:UIFontWeightMedium],
                             NSForegroundColorAttributeName: [UIColor whiteColor] };
    CGSize textSize = [text sizeWithAttributes:attrs];

    // 高度 = 图标 + 文字（留 6pt 呼吸感，不挤在一起）
    const CGFloat gap = 6.0;
    CGFloat width  = MAX(MAX(symbolSize.width, textSize.width), 30.0);
    CGFloat height = symbolSize.height + gap + textSize.height;
    CGSize size = CGSizeMake(ceil(width), ceil(height));

    UIGraphicsImageRendererFormat *format =
        [UIGraphicsImageRendererFormat formatForTraitCollection:self.traitCollection];
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:size format:format];
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        if (symbol) {
            [symbol drawInRect:CGRectMake((size.width - symbolSize.width) / 2.0, 0.0,
                                          symbolSize.width, symbolSize.height)];
        }
        [text drawAtPoint:CGPointMake((size.width - textSize.width) / 2.0, symbolSize.height + gap)
           withAttributes:attrs];
    }];
    // 模板渲染：整张图只保留形状，颜色由系统按当前外观/状态自动决定
    return [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}

// 按当前模式切换控制中心图标：低功耗 = 🐢 绿色；解除温控 = 🐰 橙色
// 形状 + 颜色双重区分，一眼就能看出当前模式
- (void)applyModeAppearance {
    BOOL lowPower = (_selectedIndex == 0);
    UIImageSymbolConfiguration *config =
        [UIImageSymbolConfiguration configurationWithPointSize:24 weight:UIImageSymbolWeightSemibold];
    UIImage *glyph = [self labeledGlyphForLowPower:lowPower];
    if (!glyph) glyph = [UIImage systemImageNamed:(lowPower ? S("tortoise.fill") : S("hare.fill")) withConfiguration:config];
    if (glyph && [self respondsToSelector:@selector(setGlyphImage:)]) {
        [self setGlyphImage:glyph];
    }
    if ([self respondsToSelector:@selector(setSelectedGlyphColor:)]) {
        [self setSelectedGlyphColor:[UIColor labelColor]];
    }
    self.title = lowPower ? S("低功耗模式") : S("解除温控模式");
}

// 系统浅色/深色切换时立刻重画图标（图标颜色跟着变黑或变白）
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection {
    [super traitCollectionDidChange:previousTraitCollection];
    if (previousTraitCollection &&
        previousTraitCollection.userInterfaceStyle != self.traitCollection.userInterfaceStyle) {
        [self applyModeAppearance];
    }
}
#pragma clang diagnostic pop

- (void)viewDidLoad {
    [super viewDidLoad];

    // 设置标题
    self.title = S("CPUthermal");

    // 设置控制中心图标（用 respondsToSelector 保护，避免私有 API 变更导致崩溃）
    [self applyModeAppearance];

    if ([self respondsToSelector:@selector(setUseTrailingCheckmarkLayout:)]) {
        [self setUseTrailingCheckmarkLayout:YES];
    }
    if ([self respondsToSelector:@selector(setUseTallLayout:)]) {
        [self setUseTallLayout:NO];
    }
    if ([self respondsToSelector:@selector(setHideGlyphInHeader:)]) {
        [self setHideGlyphInHeader:NO];
    }
    if ([self respondsToSelector:@selector(setShouldProvideOwnPlatter:)]) {
        [self setShouldProvideOwnPlatter:NO];
    }

    // 布局 UI
    [self setupView];

}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self refreshState];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self styleMenuItemLabelsAfterLayout];
}

//==============================================================================
#pragma mark - Public
//==============================================================================

- (void)refreshState {
    [self applyModeAppearance];
    [self updateSelectedIndexFromCurrentMode];
    [self setupModeButtons];
    [self updateModuleSelectedState];
}

//==============================================================================
#pragma mark - CCUIContentModuleContentViewController
//==============================================================================

- (BOOL)shouldBeginTransitionToExpandedContentModule {
    // 恢复最早几版的行为：长按由控制中心展开原生面板，面板里可以直接选择模式
    _pendingModeMenu = NO;      // 面板要展开了，取消兜底菜单
    [self updateSelectedIndexFromCurrentMode];
    [self setupModeButtons];
    return YES;
}

- (void)willTransitionToExpandedContentMode:(BOOL)animated {
    [super willTransitionToExpandedContentMode:animated];
    _pendingModeMenu = NO;   // 原生面板已展开，取消兜底菜单
    _didExpand = YES;
    // 展开时刷新菜单
    [self refreshState];
}

- (CGFloat)preferredExpandedContentHeight {
    return kCPUthermalCCPreferredExpandedHeight;
}

- (CGFloat)preferredExpandedContentWidth {
    return [self availableExpandedContentWidth];
}

- (BOOL)providesOwnPlatter {
    return NO;
}


//==============================================================================
#pragma mark - Setup
//==============================================================================

- (void)setupView {
    [self updateSelectedIndexFromCurrentMode];

    // 设置菜单项
    [self setupModeButtons];

    // 应用当前选中状态
    [self updateModuleSelectedState];
}

- (void)setupModeButtons {
    NSUInteger itemCount = MIN(self.modeValues.count, self.modeTitles.count);

    NSMutableArray *items = [NSMutableArray arrayWithCapacity:itemCount];
    for (NSUInteger i = 0; i < itemCount; i++) {
        BOOL isSelected = ((NSInteger)i == self.selectedIndex);
        // 行首标记：● 当前模式 / ○ 另一个（与说明文案一致）
        NSString *title = [NSString stringWithFormat:@"%@%@",
                                                     isSelected ? S("● ") : S("○ "),
                                                     self.modeTitles[i]];
        NSString *subtitle = i < self.modeSubtitles.count ? self.modeSubtitles[i] : S("");

        NSString *identifier = S("cpu-item-");
        identifier = [identifier stringByAppendingFormat:S("%lu"), (unsigned long)i];
        __weak typeof(self) weakSelf = self;
        NSInteger itemIndex = (NSInteger)i;
        CCUIMenuModuleItem *item = [[CCUIMenuModuleItem alloc] initWithTitle:title identifier:identifier handler:^{
            [weakSelf selectPowerModeAtIndex:itemIndex];
        }];
        if (!item) {
            continue;
        }
        if ([item respondsToSelector:@selector(setSubtitle:)]) {
            [item setSubtitle:subtitle];
        }
        if ([item respondsToSelector:@selector(setSelected:)]) {
            [item setSelected:isSelected];
        }
        // 行图标固定黑/白（由系统浅色深色决定），不带任何彩色
        if ([item respondsToSelector:@selector(setSelectedGlyphColor:)]) {
            [item setSelectedGlyphColor:[UIColor labelColor]];
        }


        [items addObject:item];
    }

    if ([self respondsToSelector:@selector(setMinimumMenuItems:)]) {
        [self setMinimumMenuItems:(NSInteger)itemCount];
    }
    if ([self respondsToSelector:@selector(setVisibleMenuItems:)]) {
        [self setVisibleMenuItems:(NSInteger)itemCount];
    }

    // 父类 setMenuItems: 有 respondsToSelector 兜底
    if ([self respondsToSelector:@selector(setMenuItems:)]) {
        self.menuItems = items;
    }

    [self styleMenuItemLabelsAfterLayout];
}

- (CGFloat)availableExpandedContentWidth {
    CGFloat width = kCPUthermalCCPreferredExpandedWidth;
    UIScreen *screen = [UIScreen mainScreen];
    CGFloat screenWidth = CGRectGetWidth(screen.bounds);
    if (screenWidth > 0) {
        width = MIN(width, screenWidth - (kCPUthermalCCMinimumScreenMargin * 2.0));
    }
    return MAX(width, 220.0);
}

- (void)styleMenuItemLabelsAfterLayout {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.view layoutIfNeeded];
        [self styleMenuItemLabelsInView:self.view];
    });
}

- (BOOL)isModeTitle:(NSString *)text {
    if (![text isKindOfClass:[NSString class]] || [text length] == 0) {
        return NO;
    }
    for (NSString *title in self.modeTitles) {
        if ([text isEqualToString:title]) {
            return YES;
        }
    }
    return NO;
}

- (BOOL)isModeSubtitle:(NSString *)text {
    if (![text isKindOfClass:[NSString class]] || [text length] == 0) {
        return NO;
    }
    for (NSString *subtitle in self.modeSubtitles) {
        if ([text isEqualToString:subtitle]) {
            return YES;
        }
    }
    return NO;
}

- (void)applyCompactMenuInsetsToLabel:(UILabel *)label inMenuItemView:(UIView *)menuItemView allowTwoLines:(BOOL)allowTwoLines {
    if (!label || !menuItemView || !label.superview || CGRectGetWidth(menuItemView.bounds) <= 0) {
        return;
    }

    UIView *labelContainer = label.superview;
    CGRect labelFrame = label.frame;
    CGPoint labelOriginInItem = [labelContainer convertPoint:labelFrame.origin toView:menuItemView];
    CGFloat maxLabelWidth = CGRectGetWidth(menuItemView.bounds) - kCPUthermalCCMenuLeadingInset - kCPUthermalCCMenuTrailingInset;
    if (maxLabelWidth <= 0) {
        return;
    }

    CGFloat adjustedMinX = MAX(labelOriginInItem.x, kCPUthermalCCMenuLeadingInset);
    CGFloat adjustedWidth = MIN(CGRectGetWidth(labelFrame), maxLabelWidth);
    if (adjustedMinX + adjustedWidth > CGRectGetWidth(menuItemView.bounds) - kCPUthermalCCMenuTrailingInset) {
        adjustedWidth = CGRectGetWidth(menuItemView.bounds) - kCPUthermalCCMenuTrailingInset - adjustedMinX;
    }
    if (adjustedWidth <= 0) {
        return;
    }

    CGPoint adjustedOrigin = [menuItemView convertPoint:CGPointMake(adjustedMinX, labelOriginInItem.y) toView:labelContainer];
    labelFrame.origin.x = adjustedOrigin.x;
    labelFrame.size.width = adjustedWidth;

    if (allowTwoLines) {
        // 两行副标题：按实际文字计算高度，并在整行内垂直居中，避免第二行被裁掉
        CGSize fitted = [label sizeThatFits:CGSizeMake(adjustedWidth, CGFLOAT_MAX)];
        CGFloat fittedHeight = ceil(fitted.height);
        if (fittedHeight > CGRectGetHeight(labelFrame)) {
            CGFloat centerYInItem = labelOriginInItem.y + CGRectGetHeight(labelFrame) / 2.0;
            CGPoint centeredOrigin = [menuItemView convertPoint:CGPointMake(adjustedMinX, centerYInItem - fittedHeight / 2.0)
                                                         toView:labelContainer];
            labelFrame.origin = centeredOrigin;
            labelFrame.size.height = fittedHeight;
        }
    }

    label.frame = labelFrame;
}

- (void)styleMenuItemLabelsInView:(UIView *)view {
    if (!view) {
        return;
    }

    NSString *className = NSStringFromClass([view class]);
    BOOL isMenuItemView = [className containsString:S("MenuModuleItem")];
    if (isMenuItemView) {
        if ([view respondsToSelector:@selector(setUseTrailingCheckmarkLayout:)]) {
            [view setUseTrailingCheckmarkLayout:YES];
        }
        if ([view respondsToSelector:@selector(setUseTrailingInset:)]) {
            [view setUseTrailingInset:YES];
        }
        if ([view respondsToSelector:@selector(setIndentation:)]) {
            [view setIndentation:kCPUthermalCCMenuLeadingInset];
        }

        UILabel *titleLabel = nil;
        UILabel *subtitleLabel = nil;
        if ([view respondsToSelector:@selector(titleLabel)]) {
            titleLabel = [view titleLabel];
        }
        if ([view respondsToSelector:@selector(subtitleLabel)]) {
            subtitleLabel = [view subtitleLabel];
        }

        NSMutableArray<UILabel *> *labels = [NSMutableArray array];
        if (titleLabel) {
            [labels addObject:titleLabel];
        }
        if (subtitleLabel && subtitleLabel != titleLabel) {
            [labels addObject:subtitleLabel];
        }
        for (UIView *subview in view.subviews) {
            if ([subview isKindOfClass:[UILabel class]] && ![labels containsObject:(UILabel *)subview]) {
                [labels addObject:(UILabel *)subview];
            }
            for (UIView *nestedSubview in subview.subviews) {
                if ([nestedSubview isKindOfClass:[UILabel class]] && ![labels containsObject:(UILabel *)nestedSubview]) {
                    [labels addObject:(UILabel *)nestedSubview];
                }
            }
        }

        for (UILabel *label in labels) {
            if (![label isKindOfClass:[UILabel class]]) {
                continue;
            }
            BOOL isTitle = [self isModeTitle:label.text];
            BOOL isSubtitle = [self isModeSubtitle:label.text];
            if (!isTitle && !isSubtitle) {
                continue;
            }
            label.textAlignment = NSTextAlignmentLeft;
            label.numberOfLines = isSubtitle ? 2 : 1;
            label.lineBreakMode = isSubtitle ? NSLineBreakByCharWrapping : NSLineBreakByTruncatingTail;
            label.adjustsFontSizeToFitWidth = isSubtitle ? NO : YES;
            label.minimumScaleFactor = 0.82;
            if (isTitle) {
                label.font = [UIFont systemFontOfSize:kCPUthermalCCTitleFontSize weight:UIFontWeightSemibold];
                label.textColor = [UIColor labelColor];
            } else {
                label.font = [UIFont systemFontOfSize:kCPUthermalCCSubtitleFontSize weight:UIFontWeightRegular];
                label.textColor = [UIColor labelColor];
            }
            [self applyCompactMenuInsetsToLabel:label inMenuItemView:view allowTwoLines:isSubtitle];
        }
    }

    for (UIView *subview in view.subviews) {
        [self styleMenuItemLabelsInView:subview];
    }
}

//==============================================================================
#pragma mark - Button Actions
//==============================================================================

- (void)updateSelectedIndexFromCurrentMode {
    NSString *currentMode = [self currentPowerMode];
    NSInteger newIndex = [self.modeValues indexOfObject:currentMode];
    if (newIndex == NSNotFound) {
        newIndex = [self.modeValues indexOfObject:S(kCPUthermalFullPowerModeC)];
    }
    _selectedIndex = newIndex;
}

// 取控制中心控件本体（那个方块视图）
- (UIView *)cpuTileButtonView {
    if ([self respondsToSelector:NSSelectorFromString(S("buttonView"))]) {
        UIView *tile = [self buttonView];
        if ([tile isKindOfClass:[UIView class]]) {
            return tile;
        }
    }
    return nil;
}

// 给控件本体挂长按识别（只挂一次）
- (void)setupTileLongPressIfNeeded {
    if (_longPressAttached) {
        return;
    }
    UIView *tile = [self cpuTileButtonView];
    if (!tile) {
        return;
    }
    UILongPressGestureRecognizer *press =
        [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleTileLongPress:)];
    press.minimumPressDuration = 0.4;
    press.cancelsTouchesInView = NO;   // 不影响单击
    [tile addGestureRecognizer:press];
    _longPressAttached = YES;
}

// 长按：震动 + 弹出模式说明
- (void)handleTileLongPress:(UILongPressGestureRecognizer *)recognizer {
    if (recognizer.state != UIGestureRecognizerStateBegan) {
        return;
    }

    _suppressNextTap = YES;   // 松手时不要被当成单击而误切模式
    _pendingModeMenu = YES;

    [self playHapticFeedback];

    __weak typeof(self) weakSelf = self;

    // 安全清理：长按标记最多保留 1.2 秒，避免影响后续单击
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf) {
            strongSelf->_suppressNextTap = NO;
        }
    });

    // 优先展开控制中心原生面板（可在面板里选择模式、看到“更省电”描述）；
    // 若系统没展开（个别机型），0.55 秒后兜底弹出同样的可选菜单
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf || !strongSelf->_pendingModeMenu || strongSelf->_didExpand) {
            return;
        }
        strongSelf->_pendingModeMenu = NO;
        strongSelf->_suppressNextTap = NO;
        [strongSelf showModeMenu];
    });
}

- (void)playHapticFeedback {
    UIImpactFeedbackGenerator *generator =
        [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [generator prepare];
    [generator impactOccurred];
}

// 长按弹出的“模式菜单”：每个模式一行，点哪行切哪个
- (void)showModeMenu {
    [self updateSelectedIndexFromCurrentMode];

    NSUInteger count = MIN(self.modeTitles.count, self.modeSubtitles.count);
    if (count == 0) {
        return;
    }

    UIAlertController *sheet =
        [UIAlertController alertControllerWithTitle:S("CPUthermal 模式")
                                           message:S("点选要用的模式")
                                    preferredStyle:UIAlertControllerStyleActionSheet];

    for (NSUInteger i = 0; i < count; i++) {
        BOOL isCurrent = ((NSInteger)i == _selectedIndex);
        NSString *rowTitle = [NSString stringWithFormat:@"%@%@ —— %@",
                                                        isCurrent ? S("● ") : S("○ "),
                                                        self.modeTitles[i],
                                                        self.modeSubtitles[i]];
        NSInteger targetIndex = (NSInteger)i;
        __weak typeof(self) weakSelf = self;
        [sheet addAction:[UIAlertAction actionWithTitle:rowTitle
                                                style:UIAlertActionStyleDefault
                                              handler:^(UIAlertAction *action) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf) {
                return;
            }
            [strongSelf selectPowerModeAtIndex:targetIndex dismissAfterSelection:NO];
            [strongSelf applyModeAppearance];
            [strongSelf playHapticFeedback];
        }]];
    }

    [sheet addAction:[UIAlertAction actionWithTitle:S("取消")
                                             style:UIAlertActionStyleCancel
                                           handler:nil]];

    // 大屏 / iPad 上用 popover 呈现，避免崩溃
    UIViewController *anchor = [self cpuPresentationHosts].firstObject;
    if (anchor && anchor.view) {
        sheet.popoverPresentationController.sourceView = anchor.view;
        sheet.popoverPresentationController.sourceRect = anchor.view.bounds;
    }

    // 按“可见窗口优先”的顺序逐个尝试呈现，失败自动换下一个
    [self presentMenu:sheet hosts:[self cpuPresentationHosts] index:0];
}

// 候选承载者：优先当前可见窗口的根控制器（控制中心模块自身的视图承载不了弹窗）
- (NSArray<UIViewController *> *)cpuPresentationHosts {
    NSMutableArray<UIViewController *> *hosts = [NSMutableArray array];

    UIViewController *(^topMost)(UIViewController *) = ^UIViewController *(UIViewController *vc) {
        UIViewController *current = vc;
        while (current.presentedViewController) {
            current = current.presentedViewController;
        }
        return current;
    };

    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) {
                continue;
            }
            for (UIWindow *window in ((UIWindowScene *)scene).windows) {
                if (window.isKeyWindow && window.rootViewController) {
                    [hosts addObject:topMost(window.rootViewController)];
                }
            }
        }
    } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        for (UIWindow *window in [UIApplication sharedApplication].windows) {
            if (window.isKeyWindow && window.rootViewController) {
                [hosts addObject:topMost(window.rootViewController)];
            }
        }
#pragma clang diagnostic pop
    }

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        if (window.rootViewController && !window.hidden) {
            UIViewController *top = topMost(window.rootViewController);
            if (![hosts containsObject:top]) {
                [hosts addObject:top];
            }
        }
    }
#pragma clang diagnostic pop

    UIView *tile = [self cpuTileButtonView];
    if (tile.window.rootViewController) {
        UIViewController *top = topMost(tile.window.rootViewController);
        if (![hosts containsObject:top]) {
            [hosts addObject:top];
        }
    }

    if (![hosts containsObject:self]) {
        [hosts addObject:self];
    }
    return hosts;
}

// 逐个尝试呈现；若前一个没成功，自动用下一个候选
- (void)presentMenu:(UIAlertController *)menu hosts:(NSArray<UIViewController *> *)hosts index:(NSUInteger)index {
    if (index >= hosts.count) {
        return;
    }
    UIViewController *host = hosts[index];
    if (host.presentedViewController) {
        [self presentMenu:menu hosts:hosts index:index + 1];
        return;
    }

    [host presentViewController:menu animated:YES completion:nil];

    __weak typeof(self) weakSelf = self;
    __weak UIViewController *weakHost = host;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        UIViewController *strongHost = weakHost;
        if (!strongSelf || !strongHost) {
            return;
        }
        // 没挂上 → 换下一个候选再试
        if (strongHost.presentedViewController != menu) {
            [strongSelf presentMenu:menu hosts:hosts index:index + 1];
        }
    });
}

// 单击控件 → 切换模式（控制中心把“单击”送到这里）
- (void)buttonTapped:(id)arg forEvent:(id)event {
    (void)arg;

    // 长按后松手：不切换模式，让 shouldBegin... 去展开面板
    if (_suppressNextTap) {
        _lastInputWasTap = NO;
        return;
    }

    _lastInputWasTap = YES;
    if ([event isKindOfClass:[UIEvent class]]) {
        UITouch *touch = ((UIEvent *)event).allTouches.allObjects.firstObject;
        if (touch && touch.tapCount <= 0) {
            _lastInputWasTap = NO;
            return;
        }
    }

    [self updateSelectedIndexFromCurrentMode];
    NSInteger itemCount = (NSInteger)self.modeValues.count;
    if (itemCount <= 0) {
        return;
    }

    NSInteger nextIndex = (self.selectedIndex + 1) % itemCount;
    [self selectPowerModeAtIndex:nextIndex dismissAfterSelection:NO];
    [self applyModeAppearance];

    // 切换生效 → 震动反馈
    [self playHapticFeedback];

    // 万一单击也把面板唤出来了，稍后自动收起（不影响长按）
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.45 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf && strongSelf->_didExpand) {
            strongSelf->_didExpand = NO;
            [strongSelf dismissViewControllerAnimated:YES completion:nil];
        }
    });
}

- (void)toggleTweakEnabled {
    // 已废弃：CPUthermal 始终启用，无需切换
}

- (void)buttonModeTapped:(CCUIMenuModuleItem *)sender {
    NSInteger index = [self.menuItems indexOfObject:sender];
    [self selectPowerModeAtIndex:index];
}

- (void)selectPowerModeAtIndex:(NSInteger)index {
    [self selectPowerModeAtIndex:index dismissAfterSelection:YES];
}

- (void)selectPowerModeAtIndex:(NSInteger)index dismissAfterSelection:(BOOL)dismissAfterSelection {
    if (index == NSNotFound || index < 0 || index >= (NSInteger)self.modeValues.count) {
        return;
    }

    _selectedIndex = index;
    NSString *modeValue = self.modeValues[index];

    // 写入偏好设置并通知 tweak
    [self savePowerMode:modeValue];

    // 刷新 UI（含控制中心图标上的小注）
    [self setupModeButtons];
    [self updateModuleSelectedState];
    [self applyModeAppearance];

    if (!dismissAfterSelection) {
        return;
    }

    // 短暂延迟后折叠
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:nil];
    });
}

- (void)updateModuleSelectedState {
    // 关键：不上报“已开启/选中”。一旦上报，系统会给控件套“开启样式”
    // （白底 + 深色图标），看起来就和旁边不一样了。
    if ([self respondsToSelector:@selector(setSelected:)]) {
        [self setSelected:NO];
    }
}

//==============================================================================
#pragma mark - Properties
//==============================================================================

- (NSArray<NSString *> *)modeValues {
    return _modeValues;
}

- (void)setModeValues:(NSArray<NSString *> *)modeValues {
    _modeValues = [modeValues copy];
    [self setupModeButtons];
}

- (NSArray<NSString *> *)modeTitles {
    return _modeTitles;
}

- (void)setModeTitles:(NSArray<NSString *> *)modeTitles {
    _modeTitles = [modeTitles copy];
    [self setupModeButtons];
}

- (NSArray<NSString *> *)modeSubtitles {
    return _modeSubtitles;
}

- (void)setModeSubtitles:(NSArray<NSString *> *)modeSubtitles {
    _modeSubtitles = [modeSubtitles copy];
    [self setupModeButtons];
}

- (NSInteger)selectedIndex {
    return _selectedIndex;
}

- (void)setSelectedIndex:(NSInteger)selectedIndex {
    _selectedIndex = selectedIndex;
    [self setupModeButtons];
}

@end
