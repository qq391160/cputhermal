#import "CPUthermalCCModuleViewController.h"
#import <notify.h>
#import <Foundation/Foundation.h>
#import <spawn.h>
#import <CPUthermalPaths.h>
#import <dlfcn.h>   // 私有 IOReport 动态加载
#include <sys/sysctl.h>
#import <IOKit/IOKitLib.h>   // 读 IORegistry（CPU 频率表 / 诊断探针）
#import <math.h>

// ============================================================
// 注意: 禁止使用 @"" ObjC 字符串常量
// roothide 重映射会破坏 __cfstring 内部指针，导致 SIGBUS
// 所有字符串通过 C 字符串 + stringWithUTF8String: 动态创建
// ============================================================

@interface CPUthermalCCModuleViewController () {
    BOOL _lastInputWasTap;   // 上一次输入是否为“单击”，用于区分单击 / 长按
    BOOL _suppressNextTap;   // 长按后松手，避免被当成单击误切模式
    BOOL _longPressAttached; // 是否已给控件本体挂上长按识别
    BOOL _pendingModeMenu;   // 系统面板没展开时的兜底菜单
    BOOL _didExpand;         // 面板是否真的展开过（用于单击后自动收起）
    NSInteger _freqFail;
    double _peakMHz;            // 最近 5 秒内的最高频率
    NSTimeInterval _peakAt;     // 峰值出现的时间
    NSInteger _peakModeIndex;   // 峰值属于哪个模式（换模式就重算）
    int _lastCapMHz;            // 上次画的上限频率，变了才重画        // 连续读不到频率的次数（避免抖动）
    dispatch_source_t _freqTimer;   // 实时频率刷新定时器
}
- (void)updateSelectedIndexFromCurrentMode;
- (void)refreshFrequencyGlyph;
- (void)applyFixedGlyphMHz:(int)mhz;
- (void)applyPeakGlyphMHz:(double)peak capMHz:(int)cap;
- (void)refreshPeakGlyph;
- (int)systemDisplayMHz;
- (int)cappedFrequencyMHz;
- (BOOL)isTweakEnabled;
- (void)saveTweakEnabled:(BOOL)enabled;
- (void)toggleTweakEnabled;
- (void)updateModuleSelectedState;
- (void)selectPowerModeAtIndex:(NSInteger)index;
- (void)selectPowerModeAtIndex:(NSInteger)index dismissAfterSelection:(BOOL)dismissAfterSelection;
- (CGFloat)availableExpandedContentWidth;
- (void)applyCompactMenuInsetsToLabel:(UILabel *)label inMenuItemView:(UIView *)menuItemView;
- (void)styleMenuItemLabelsInView:(UIView *)view;
- (void)styleMenuItemLabelsAfterLayout;
- (BOOL)isModeTitle:(NSString *)text;
- (BOOL)isModeSubtitle:(NSString *)text;
- (UIView *)cpuTileButtonView;
- (void)setupTileLongPressIfNeeded;
- (void)handleTileLongPress:(UILongPressGestureRecognizer *)recognizer;
- (void)playHapticFeedback;
- (void)showModeMenu;
- (NSArray<UIViewController *> *)cpuPresentationHosts;
- (void)presentMenu:(UIAlertController *)menu hosts:(NSArray<UIViewController *> *)hosts index:(NSUInteger)index;
@end

static const CGFloat kCPUthermalCCPreferredExpandedWidth = 320.0;
static const CGFloat kCPUthermalCCPreferredExpandedHeight = 250.0;
static const CGFloat kCPUthermalCCMinimumScreenMargin = 30.0;
static const CGFloat kCPUthermalCCMenuLeadingInset = 18.0;
static const CGFloat kCPUthermalCCMenuTrailingInset = 46.0;
static const CGFloat kCPUthermalCCTitleFontSize = 15.0;
static const CGFloat kCPUthermalCCSubtitleFontSize = 11.0;
// 兜底值（正常情况下都从系统频率表实时读取，读不到才用这两个）
static const int kCTSystemLowPowerMHz = 2112;   // 小核（E 核）最高档
static const int kCTSystemFullMHz      = 3780;  // 大核（P 核）最高档

@interface UIView (CPUthermalCCPrivateLayout)
- (UILabel *)titleLabel;
- (UILabel *)subtitleLabel;
- (UIView *)contentView;
- (void)setUseTrailingCheckmarkLayout:(BOOL)useTrailingCheckmarkLayout;
- (void)setUseTrailingInset:(BOOL)useTrailingInset;
- (void)setIndentation:(CGFloat)indentation;
@end

//==============================================================================
#pragma mark - 实时 CPU 频率（IOReport 私有接口 / dlopen 加载 / 读不到就回落原图标）
//==============================================================================
// 说明：所有 CFString 都用 CFStringCreateWithCString 运行时创建，
//       绝不使用 CFSTR()/@"" 常量（rootHide 下 __cfstring 会 SIGBUS）。

typedef CFMutableDictionaryRef (*CTIOR_CopyChannelsInGroup)(CFStringRef, CFStringRef, uint64_t, uint64_t, uint64_t);
typedef CFMutableDictionaryRef (*CTIOR_CreateSubscription)(void *, CFMutableDictionaryRef, CFMutableDictionaryRef *, uint64_t, CFTypeRef);
typedef CFDictionaryRef (*CTIOR_CreateSamples)(CFMutableDictionaryRef, CFMutableDictionaryRef, CFTypeRef);
typedef int (*CTIOR_Iterate)(CFDictionaryRef, int (^)(CFDictionaryRef));
typedef CFStringRef (*CTIOR_ChannelGetChannelName)(CFDictionaryRef);
typedef CFStringRef (*CTIOR_ChannelGetSubGroup)(CFDictionaryRef);
typedef int (*CTIOR_StateGetCount)(CFDictionaryRef);
typedef CFStringRef (*CTIOR_StateGetNameForIndex)(CFDictionaryRef, int);
typedef int64_t (*CTIOR_StateGetResidency)(CFDictionaryRef, int);

static void *g_ctIOReport = NULL;
static BOOL g_ctIOReportTried = NO;
static CTIOR_CopyChannelsInGroup g_ctCopyChannels = NULL;
static CTIOR_CreateSubscription g_ctCreateSubscription = NULL;
static CTIOR_CreateSamples g_ctCreateSamples = NULL;
static CTIOR_Iterate g_ctIterate = NULL;
static CTIOR_ChannelGetChannelName g_ctChannelName = NULL;
static CTIOR_ChannelGetSubGroup g_ctChannelSubGroup = NULL;
static CTIOR_StateGetCount g_ctStateCount = NULL;
static CTIOR_StateGetNameForIndex g_ctStateName = NULL;
static CTIOR_StateGetResidency g_ctStateResidency = NULL;
static CFMutableDictionaryRef g_ctSub = NULL;
static CFMutableDictionaryRef g_ctSubbed = NULL;
static BOOL g_ctProbeDumped __attribute__((unused)) = NO;
static NSInteger g_ctFreqErrCode = 0;
static int g_ctFreqMaxStates = 0;
static NSMutableString *g_ctFreqScanLog = nil;
static NSInteger g_ctFreqRelChans = 0;       // 本次采样里「CPU 相关通道」的个数
static int g_ctProbeWrites = 0;              // 探针最多写 3 次（加载时1次 + 失败时2次）
#define kCTBuildTag "build 0914-1320"   // 版本标记：看一眼探针就知道是新是旧   // 扫描设备树时记下的频率表候选（诊断用）      // 通道里的最大状态数
static int g_ctFreqStateChans = 0;     // 有状态的通道个数
static NSString *g_ctFreqStateName = nil;   // 选中状态的名字（诊断用）   // 0正常 1dlopen失败 2无通道 3订阅失败 4采样失败 5读不到状态
static double g_ctLastMHz = -1.0;
static NSMutableDictionary *g_ctPrevRes = nil;   // 上一次采样的累计状态计数（用来算这一秒的差值）

// 把原始值归一成 MHz：> 1e7 当 Hz，> 1e4 当 kHz，否则当 MHz
static double CTFreqNormalizeMHz(long long raw) {
    double v = (double)raw;
    if (v > 10000000.0) return v / 1000000.0;
    if (v > 10000.0)    return v / 1000.0;
    return v;
}

static CFStringRef CTCFStr(const char *s) {
    return s ? CFStringCreateWithCString(kCFAllocatorDefault, s, kCFStringEncodingUTF8) : NULL;
}

static BOOL CTFreqLoad(void) {
    if (g_ctIOReportTried) return g_ctIOReport != NULL;
    g_ctIOReportTried = YES;
    g_ctIOReport = dlopen("/System/Library/PrivateFrameworks/IOReport.framework/IOReport", RTLD_LAZY);
    if (!g_ctIOReport) g_ctIOReport = dlopen("/usr/lib/libIOReport.dylib", RTLD_LAZY);
    if (!g_ctIOReport) return NO;
    g_ctCopyChannels       = (CTIOR_CopyChannelsInGroup)dlsym(g_ctIOReport, "IOReportCopyChannelsInGroup");
    g_ctCreateSubscription = (CTIOR_CreateSubscription)dlsym(g_ctIOReport, "IOReportCreateSubscription");
    g_ctCreateSamples      = (CTIOR_CreateSamples)dlsym(g_ctIOReport, "IOReportCreateSamples");
    g_ctIterate            = (CTIOR_Iterate)dlsym(g_ctIOReport, "IOReportIterate");
    g_ctChannelName        = (CTIOR_ChannelGetChannelName)dlsym(g_ctIOReport, "IOReportChannelGetChannelName");
    g_ctChannelSubGroup    = (CTIOR_ChannelGetSubGroup)dlsym(g_ctIOReport, "IOReportChannelGetSubGroup");
    g_ctStateCount         = (CTIOR_StateGetCount)dlsym(g_ctIOReport, "IOReportStateGetCount");
    g_ctStateName          = (CTIOR_StateGetNameForIndex)dlsym(g_ctIOReport, "IOReportStateGetNameForIndex");
    g_ctStateResidency     = (CTIOR_StateGetResidency)dlsym(g_ctIOReport, "IOReportStateGetResidency");
    return (g_ctCopyChannels && g_ctCreateSubscription && g_ctCreateSamples && g_ctIterate &&
            g_ctStateCount && g_ctStateName && g_ctStateResidency);
}

static BOOL CTFreqSetup(void) {
    if (g_ctSub && g_ctSubbed) return YES;
    if (!CTFreqLoad()) { g_ctFreqErrCode = 1; return NO; }

    static const char *pairs[][2] = {
        { "CPU Stats", NULL },
        { "CPU Stats", "CPU Complex Performance States" },
        { "CPU Stats", "CPU Performance States" },
        { "PMP", NULL },
        { "SoC Stats", NULL },
        { NULL, NULL }
    };

    CFMutableDictionaryRef bestRel = NULL, bestRelSubbed = NULL;   // 含 CPU 频率通道的
    CFMutableDictionaryRef bestAny = NULL, bestAnySubbed = NULL;   // 兜底：其它
    int bestRelStates = 0, bestAnyStates = -1;
    for (int pi = 0; pairs[pi][0]; pi++) {
        CFStringRef g  = CTCFStr(pairs[pi][0]);
        CFStringRef sg = pairs[pi][1] ? CTCFStr(pairs[pi][1]) : NULL;
        CFMutableDictionaryRef chans = g_ctCopyChannels(g, sg, 0, 0, 0);
        if (g) CFRelease(g);
        if (sg) CFRelease(sg);
        if (!chans) continue;

        CFMutableDictionaryRef subbed = NULL;
        CFMutableDictionaryRef sub = g_ctCreateSubscription(NULL, chans, &subbed, 0, NULL);
        int totalStates = 0, chansWithStates = 0, anyOnly = 0;
        if (sub && subbed && g_ctCreateSamples && g_ctIterate && g_ctStateCount) {
            CFDictionaryRef samples = g_ctCreateSamples(sub, subbed, NULL);
            if (samples) {
                __block int tot = 0, cnt = 0, anyTot = 0;
                g_ctIterate(samples, ^int(CFDictionaryRef ch) {
                    int n = g_ctStateCount(ch);
                    if (n <= 0) return 0;
                    anyTot += n;
                    NSString *sub = g_ctChannelSubGroup ? (__bridge NSString *)g_ctChannelSubGroup(ch) : nil;
                    BOOL rel = (sub && ([sub containsString:S("Complex Voltage States")] ||
                                        [sub containsString:S("Complex Performance States")]));
                    if (rel) { tot += n; cnt++; }
                    return 0;
                });
                totalStates = tot; chansWithStates = cnt;
                if (cnt == 0) anyOnly = anyTot;
                CFRelease(samples);
            }
        }
        CFRelease(chans);

        if (sub && subbed && totalStates > bestRelStates) {          // 优先：真有 CPU 频率通道的
            if (bestRel) CFRelease(bestRel);
            if (bestRelSubbed) CFRelease(bestRelSubbed);
            bestRel = sub; bestRelSubbed = subbed;
            bestRelStates = totalStates;
            g_ctFreqStateChans = chansWithStates;
        } else if (sub && subbed && anyOnly > bestAnyStates) {        // 兜底
            if (bestAny) CFRelease(bestAny);
            if (bestAnySubbed) CFRelease(bestAnySubbed);
            bestAny = sub; bestAnySubbed = subbed;
            bestAnyStates = anyOnly;
        } else {
            if (sub) CFRelease(sub);
            if (subbed) CFRelease(subbed);
        }
    }

    if (bestRel && bestRelSubbed) {
        if (bestAny) CFRelease(bestAny);
        if (bestAnySubbed) CFRelease(bestAnySubbed);
        g_ctSub = bestRel; g_ctSubbed = bestRelSubbed;
        g_ctFreqErrCode = 0;
        return YES;
    }
    if (bestAny && bestAnySubbed) {
        g_ctSub = bestAny; g_ctSubbed = bestAnySubbed;
        g_ctFreqErrCode = 0;
        return YES;
    }
    g_ctFreqErrCode = 2;
    return NO;
}
// 从 “P3: 2400MHz / 2.4GHz” 这类状态名里直接读频率
static double CTFreqParseStateNameMHz(CFStringRef name) {
    if (!name) return -1;
    NSString *s = [(__bridge NSString *)name lowercaseString];
    NSRange r = [s rangeOfString:@"ghz"];
    double mult = 1000.0;
    if (r.location == NSNotFound) { r = [s rangeOfString:@"mhz"]; mult = 1.0; }
    if (r.location == NSNotFound) return -1;
    // 往前取数字（含小数点）
    NSInteger end = (NSInteger)r.location;
    NSInteger start = end;
    while (start > 0) {
        unichar c = [s characterAtIndex:(NSUInteger)(start - 1)];
        if ((c >= '0' && c <= '9') || c == '.') start--; else break;
    }
    if (start >= end) return -1;
    double v = [[s substringWithRange:NSMakeRange((NSUInteger)start, (NSUInteger)(end - start))] doubleValue];
    if (v <= 0) return -1;
    return v * mult;
}

// 读某颗 CPU 的 DVFS 频率表（取状态数最接近的那张）
// 解析一段 uint32 数组：按 (频率,电压) 成对取频率，两种排列都试，用电压做合理性校验
static NSArray<NSNumber *> *CTFreqParsePairArray(id v, int want, NSInteger *score) {
    if (![v isKindOfClass:[NSData class]]) return nil;
    NSData *data = (NSData *)v;
    NSUInteger n = data.length / 4;
    if (n < 6) return nil;
    const uint32_t *w = (const uint32_t *)data.bytes;
    NSArray<NSNumber *> *best = nil;
    NSInteger bestScore = -1;
    for (int flip = 0; flip < 2; flip++) {
        NSMutableArray<NSNumber *> *freqs = [NSMutableArray array];
        BOOL ok = YES, asc = YES;
        double prev = 0;
        for (NSUInteger idx = 0; idx + 1 < n; idx += 2) {
            double a = w[idx], b = w[idx + 1];
            double f = flip ? b : a, volt = flip ? a : b;
            if (volt > 10000.0) volt /= 1000.0;              // µV → mV
            if (volt < 300.0 || volt > 1600.0) { ok = NO; break; }
            double mhz = CTFreqNormalizeMHz((long long)f);
            if (mhz < 200.0 || mhz > 4600.0) { ok = NO; break; }
            if (mhz < prev) asc = NO;
            prev = mhz;
            [freqs addObject:@(mhz)];
        }
        if (!ok || freqs.count < 3) continue;
        NSInteger delta = 0;
        if (want > 0) {
            delta = labs((long)((NSInteger)freqs.count - want));
            if (delta > 1) continue;                          // 长度要接近状态数（允许差 1 个 IDLE）
        }
        NSInteger sc = 100 - delta * 20 + (asc ? 10 : 0);
        if (sc > bestScore) { bestScore = sc; best = freqs; }
    }
    if (best && score) *score = bestScore;
    return best;
}

// 解析「纯频率列表」：整段都是 200~4600MHz 的升序值
static NSArray<NSNumber *> *CTFreqParsePlainArray(id v, int want, NSInteger *score) {
    if (![v isKindOfClass:[NSData class]]) return nil;
    NSData *data = (NSData *)v;
    NSUInteger n = data.length / 4;
    if (n < 3) return nil;
    const uint32_t *w = (const uint32_t *)data.bytes;
    NSMutableArray<NSNumber *> *freqs = [NSMutableArray array];
    double prev = 0;
    BOOL asc = YES;
    for (NSUInteger i = 0; i < n; i++) {
        double mhz = CTFreqNormalizeMHz((long long)w[i]);
        if (mhz < 200.0 || mhz > 4600.0) return nil;
        if (mhz < prev) asc = NO;
        prev = mhz;
        [freqs addObject:@(mhz)];
    }
    NSInteger delta = 0;
    if (want > 0) {
        delta = labs((long)((NSInteger)freqs.count - want));
        if (delta > 1) return nil;
    }
    if (score) *score = 90 - delta * 20 + (asc ? 10 : 0);
    return freqs;
}

// 递归扫设备树找频率表；先只找属性名含 voltage-states 的，找不到再全扫
static void CTFreqScanTree(io_registry_entry_t node, int depth, int want, BOOL onlyVoltageStates,
                           NSArray<NSNumber *> **best, NSInteger *bestScore, int *visited) {
    if (depth > 4 || (*visited) > 300) return;
    (*visited)++;
    char nodePath[512] = {0};
    IORegistryEntryGetPath(node, "IODeviceTree", nodePath);
    CFMutableDictionaryRef props = NULL;
    if (IORegistryEntryCreateCFProperties(node, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = CFBridgingRelease(props);
        for (NSString *k in d.allKeys) {
            if (onlyVoltageStates && ![k containsString:S("voltage-states")]) continue;
            NSInteger scPair = -1, scPlain = -1;
            NSArray<NSNumber *> *tPair = CTFreqParsePairArray(d[k], want, &scPair);
            NSArray<NSNumber *> *tPlain = CTFreqParsePlainArray(d[k], want, &scPlain);
            NSInteger sc = (scPlain > scPair) ? scPlain : scPair;
            NSArray<NSNumber *> *t = (scPlain > scPair) ? tPlain : tPair;
            if (t) {
                if (!g_ctFreqScanLog) g_ctFreqScanLog = [NSMutableString string];
                if (g_ctFreqScanLog.length < 4000) {
                    [g_ctFreqScanLog appendFormat:S("%s [%@] 档数=%lu 得分=%ld 值=%@\n"),
                     nodePath, k, (unsigned long)t.count, (long)sc,
                     [t componentsJoinedByString:S(",")]];
                }
            }
            if (t && sc > *bestScore) { *bestScore = sc; *best = t; }
        }
    }
    static const char *planes[] = { "IODeviceTree", "IOService" };
    for (int pi = 0; pi < 2; pi++) {
        if (*best) break;
        io_iterator_t it = 0;
        if (IORegistryEntryGetChildIterator(node, planes[pi], &it) != KERN_SUCCESS) continue;
        io_registry_entry_t child = 0;
        while ((child = IOIteratorNext(it))) {
            CTFreqScanTree(child, depth + 1, want, onlyVoltageStates, best, bestScore, visited);
            IOObjectRelease(child);
        }
        IOObjectRelease(it);
    }
}

// 实时扫描：每次都重新从系统（设备树）读，不做任何缓存
static NSArray<NSNumber *> *CTFreqTableScan(int stateCount) {
    NSArray<NSNumber *> *best = nil;
    NSInteger bestScore = -1;
    int visited = 0;
    io_registry_entry_t root = IORegistryEntryFromPath(MACH_PORT_NULL, "IODeviceTree:/");
    if (root) {
        CTFreqScanTree(root, 0, stateCount, YES, &best, &bestScore, &visited);
        if (!best) { visited = 0; CTFreqScanTree(root, 0, stateCount, NO, &best, &bestScore, &visited); }
        IOObjectRelease(root);
    }
    if (best.count >= 2) best = [best sortedArrayUsingSelector:@selector(compare:)];
    if (!best) {   // 设备树里没搜到才用实测档位表兜底（A17 Pro）
        if (stateCount == 5) {
            best = @[ @744, @960, @1344, @1728, @2112 ];
        } else if (stateCount == 17) {
            best = @[ @576, @1092, @1344, @1584, @1824, @2064, @2304, @2544, @2724, @2904,
                      @3084, @3264, @3444, @3564, @3684, @3732, @3780 ];
        }
    }
    return best;
}

// 带缓存的版本（只有历史实时频率代码在用）
static NSArray<NSNumber *> *CTFreqTableMatching(int stateCount) {
    static NSMutableDictionary *cache = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ cache = [NSMutableDictionary dictionary]; });
    NSNumber *key = @(stateCount);
    if (cache[key]) return cache[key];
    NSArray<NSNumber *> *best = CTFreqTableScan(stateCount);
    if (best) cache[key] = best;
    return best;
}

// 从系统频率表里读「最高档」= 这个模式能跑到的 CPU 最大值
// 每次都重新读设备树（实时）；读不到返回 0，由调用方兜底
static int CTFreqSystemMaxMHz(int stateCount) {
    NSArray<NSNumber *> *tbl = CTFreqTableScan(stateCount);
    if (tbl.count == 0) return 0;
    return (int)[tbl.lastObject doubleValue];
}

// 取一次实时频率：返回当前“最高正在跑”的那个核心簇频率（MHz）
#include <notify.h>

// 系统热压力等级（thermalmonitord 广播）：0 正常 / 10 轻 / 20 中 / 30 重 / 40 / 50
// 读不到返回 -1（那就当作"没发热"，显示最高档）
static int __attribute__((unused)) CTThermalPressureLevel(void) {
    static int ctTpToken = -1;
    static BOOL ctTpTried = NO;
    if (!ctTpTried) {
        ctTpTried = YES;
        int t = 0;
        if (notify_register_check("com.apple.system.thermalpressurelevel", &t) == NOTIFY_STATUS_OK) {
            ctTpToken = (int)t;
        }
    }
    if (ctTpToken < 0) return -1;
    uint64_t st = 0;
    if (notify_get_state(ctTpToken, &st) != NOTIFY_STATUS_OK) return -1;
    return (int)st;
}

static BOOL CTFreqReadMHz(double *outMHz) {
    if (!CTFreqSetup()) return NO;
    CFDictionaryRef samples = g_ctCreateSamples(g_ctSub, g_ctSubbed, NULL);
    if (!samples) { g_ctFreqErrCode = 4; return NO; }

    __block double best = -1.0;
    __block BOOL sawActive = NO;
    __block NSInteger relChans = 0;
    __block int bestPrio = 0;
    __block int maxStates = 0;
    g_ctIterate(samples, ^int(CFDictionaryRef ch) {
        int n = g_ctStateCount(ch);
        if (n <= 0) return 0;
        if (n > maxStates) maxStates = n;

        // 只认两种通道：CPU Complex Voltage States（无 IDLE、下标对齐）
        //              CPU Complex Performance States（多一个 IDLE，下标要 -1）
        NSString *sub = g_ctChannelSubGroup ? (__bridge NSString *)g_ctChannelSubGroup(ch) : nil;
        NSString *cname = g_ctChannelName ? (__bridge NSString *)g_ctChannelName(ch) : nil;
        BOOL isVoltStates = (sub && [sub containsString:S("Complex Voltage States")]);
        BOOL isPerfStates = (sub && [sub containsString:S("Complex Performance States")]);
        if (!isVoltStates && !isPerfStates) return 0;   // DVD 百分比、核心级通道都不要
        relChans++;
        // 优先级：大核 PCPU 的 Voltage States（3）> 其它 Voltage States（2）> Performance States（1）
        int prio = isVoltStates ? ([cname hasPrefix:S("PCPU")] ? 3 : 2) : 1;
        if (prio < bestPrio) return 0;

        if (!g_ctPrevRes) g_ctPrevRes = [NSMutableDictionary dictionary];
        // 取「这一秒内有活动过的最高档」= 实时最高频率
        // （状态计数是累计值 → 用本次与上次采样的差值判断"这一秒到底用没用过"）
        int hi = -1;
        int topIdx = -1;
        int64_t bestRes = 0;
        int base = isPerfStates ? 1 : 0;                 // Performance States 第 0 档是 IDLE
        for (int i = 0; i < n; i++) {
            int64_t r = g_ctStateResidency(ch, i);
            if (r > bestRes) { bestRes = r; hi = i; }
            NSString *rk = [NSString stringWithFormat:@"%@#%d", cname, i];
            NSNumber *prev = g_ctPrevRes[rk];
            int64_t d = prev ? (r - prev.longLongValue) : 0;
            g_ctPrevRes[rk] = @(r);
            if (d > 0 && i >= base) {
                int idx = i - base;
                if (idx > topIdx) topIdx = idx;
            }
        }
        if (hi < 0) return 0;
        sawActive = YES;

        int useIdx = (topIdx >= 0) ? topIdx : (isPerfStates ? (hi - 1) : hi);
        if (useIdx < 0) return 0;                        // 命中的是 IDLE 档，不算频率
        int want = isPerfStates ? (n - 1) : n;
        int si   = isPerfStates ? (useIdx + 1) : useIdx;  // 对应的状态名下标
        CFStringRef nmRef = (si >= 0 && si < n) ? g_ctStateName(ch, si) : NULL;
        NSString *nmStr = nmRef ? (__bridge NSString *)nmRef : nil;
        double mhz = CTFreqParseStateNameMHz(nmRef);
        if (mhz <= 0) {
            NSArray<NSNumber *> *tbl = CTFreqTableMatching(want);
            if (tbl && useIdx < (int)tbl.count) mhz = tbl[useIdx].doubleValue;
        }
        if (mhz > 0) {
            if (prio > bestPrio) { bestPrio = prio; best = mhz; }
            else if (mhz > best) best = mhz;
            if (nmStr) g_ctFreqStateName = [nmStr copy];
        }
        return 0;
    });
    CFRelease(samples);
    g_ctFreqMaxStates = maxStates;
    g_ctFreqRelChans = relChans;   // cN：相关通道个数（诊断用）

    if (best >= 200.0 && best <= 6000.0) { if (outMHz) *outMHz = best; g_ctFreqErrCode = 0; return YES; }
    g_ctFreqErrCode = sawActive ? 6 : 5;
    return NO;
}

// ---- 探针 V2（只读）：把系统里所有「像频率表」的属性整张列出来，不截断、不限定名字 ----
static void CTFreqPrintValue(NSMutableString *s, NSString *key, id v) {
    if ([v isKindOfClass:[NSData class]]) {
        NSData *d = (NSData *)v;
        NSUInteger n = d.length / 4;
        if (n == 0 || n > 4096) return;
        const uint32_t *p = (const uint32_t *)d.bytes;
        int inRange = 0;
        for (NSUInteger i = 0; i < n; i++) if (p[i] >= 200 && p[i] <= 5000) inRange++;
        [s appendFormat:S("  %s [uint32 x%lu]%s : "), key.UTF8String, (unsigned long)n,
                          (inRange >= 3 ? " ★像频率表" : "")];
        for (NSUInteger i = 0; i < n && i < 200; i++) [s appendFormat:S("%u,"), p[i]];
        if (n > 200) [s appendString:S("...(超过200个已截断)")];
        [s appendString:S("\n")];
    } else if ([v isKindOfClass:[NSNumber class]] || [v isKindOfClass:[NSString class]]) {
        [s appendFormat:S("  %s = %@\n"), key.UTF8String, v];
    }
}

// 递归遍历某棵 IO 树，把「含 state/freq/volt/clock/perf 的属性」全写出来
static void CTFreqWalkAll(io_registry_entry_t node, int depth, NSMutableString *s, NSString *path,
                          int *count, int maxNodes) {
    if (*count >= maxNodes || depth > 6) return;
    (*count)++;
    CFMutableDictionaryRef props = NULL;
    if (IORegistryEntryCreateCFProperties(node, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
        NSDictionary *d = (__bridge_transfer NSDictionary *)props;
        NSMutableString *hits = [NSMutableString string];
        for (NSString *k in d) {
            if ([k hasPrefix:S("IO")]) continue;
            BOOL nameHit = ([k rangeOfString:S("state")].location != NSNotFound ||
                            [k rangeOfString:S("freq")].location != NSNotFound ||
                            [k rangeOfString:S("volt")].location != NSNotFound ||
                            [k rangeOfString:S("clock")].location != NSNotFound ||
                            [k rangeOfString:S("perf")].location != NSNotFound);
            if (!nameHit) continue;
            CTFreqPrintValue(hits, k, d[k]);
        }
        if (hits.length > 0) [s appendFormat:S("\n[%s]\n%@"), path.UTF8String, hits];
    }
    io_iterator_t it = 0;
    if (IORegistryEntryGetChildIterator(node, MACH_PORT_NULL, &it) == KERN_SUCCESS) {
        io_registry_entry_t ch;
        while ((ch = IOIteratorNext(it))) {
            char nm[128] = {0};
            IORegistryEntryGetName(ch, nm);
            NSString *sub = [path stringByAppendingPathComponent:[NSString stringWithUTF8String:nm]];
            CTFreqWalkAll(ch, depth + 1, s, sub, count, maxNodes);
            IOObjectRelease(ch);
        }
        IOObjectRelease(it);
    }
}

// 读不到时把现场信息写到 /tmp，方便下一轮修正（只写一次）
// ---- 探针 V2 入口：两棵树全量转储（只读，不写任何设置）----
static void CTFreqDumpTablesV2(void) {
    NSMutableString *s = [NSMutableString string];
    [s appendFormat:S("=== CPUthermal 频率来源全量转储（%s）===\n"), kCTBuildTag];
    int c1 = 0;
    io_registry_entry_t dt = IORegistryEntryFromPath(MACH_PORT_NULL, "IODeviceTree:/");
    if (dt) {
        [s appendString:S("\n########## 设备树（只列属性名含 state/freq/volt/clock/perf 的）\n")];
        CTFreqWalkAll(dt, 0, s, S("/"), &c1, 900);
        IOObjectRelease(dt);
    }
    int c2 = 0;
    io_registry_entry_t sv = IORegistryEntryFromPath(MACH_PORT_NULL, "IOService:/");
    if (sv) {
        [s appendString:S("\n########## 服务树（同上过滤；AppleCLPC/ApplePPM 等在这里）\n")];
        CTFreqWalkAll(sv, 0, s, S("/"), &c2, 900);
        IOObjectRelease(sv);
    }
    [s appendFormat:S("\n=== 完：设备树节点 %d 个，服务树节点 %d 个 ===\n"), c1, c2];
    [s writeToFile:S("/tmp/CPUthermalTables.txt") atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    NSData *d = [s dataUsingEncoding:NSUTF8StringEncoding];
    if (d) [d writeToFile:S("/var/mobile/Library/Logs/CPUthermalTables.txt") atomically:YES];
}

static void CTFreqDumpProbe(void) {
    if (g_ctProbeWrites >= 3) return;
    g_ctProbeWrites++;
    NSMutableString *s = [NSMutableString string];
    [s appendFormat:S("=== CPUthermal 频率诊断（%s）===\n"), kCTBuildTag];
    [s appendFormat:S("dlopen IOReport: %s\n"), g_ctIOReport ? "OK" : "失败"];
    [s appendFormat:S("subscription: %s\n"), (g_ctSub && g_ctSubbed) ? "OK" : "失败"];
    [s appendString:S("\n--- IOReport 通道 / 状态名 ---\n")];
    if (g_ctSub && g_ctSubbed && g_ctCreateSamples && g_ctIterate) {
        CFDictionaryRef samples = g_ctCreateSamples(g_ctSub, g_ctSubbed, NULL);
        if (samples) {
            g_ctIterate(samples, ^int(CFDictionaryRef ch) {
                CFStringRef nm = g_ctChannelName ? g_ctChannelName(ch) : NULL;
                CFStringRef sg = g_ctChannelSubGroup ? g_ctChannelSubGroup(ch) : NULL;
                int n = g_ctStateCount(ch);
                NSMutableArray *states = [NSMutableArray array];
                for (int i = 0; i < n; i++) {
                    CFStringRef sn = g_ctStateName(ch, i);
                    if (sn) [states addObject:(__bridge NSString *)sn];
                }
                [s appendFormat:S("通道=%@ 子组=%@ 状态数=%d [%@]\n"),
                 nm ? (__bridge NSString *)nm : S("?"),
                 sg ? (__bridge NSString *)sg : S("?"), n,
                 [states componentsJoinedByString:S(", ")]];
                return 0;
            });
            CFRelease(samples);
        }
    }
    [s appendString:S("\n--- /cpus/cpu0 属性 ---\n")];
    io_registry_entry_t node = IORegistryEntryFromPath(MACH_PORT_NULL, "IODeviceTree:/cpus/cpu0");
    if (node) {
        CFMutableDictionaryRef props = NULL;
        if (IORegistryEntryCreateCFProperties(node, &props, kCFAllocatorDefault, 0) == KERN_SUCCESS && props) {
            NSDictionary *d = CFBridgingRelease(props);
            for (NSString *k in d.allKeys) {
                id v = d[k];
                NSString *desc = nil;
                if ([v isKindOfClass:[NSData class]]) {
                    NSData *dd = (NSData *)v;
                    NSUInteger words = dd.length / 4;
                    const uint32_t *wp = (const uint32_t *)dd.bytes;
                    NSMutableString *vals = [NSMutableString string];
                    for (NSUInteger x = 0; x < words && x < 8; x++) [vals appendFormat:S(" %u"), wp[x]];
                    desc = [NSString stringWithFormat:S("<data %lu 字节 / %lu 个uint32:%@>"),
                            (unsigned long)dd.length, (unsigned long)words, vals];
                } else {
                    desc = [v description];
                }
                [s appendFormat:S("%@ = %@\n"), k, desc];
            }
        }
        IOObjectRelease(node);
    }
    // ---- 1) 电源管理相关 IOKit 服务属性（频率表最可能存在的地方）----
    [s appendString:S("\n--- 电源管理服务属性 ---\n")];
    const char *svcNames[] = { "AppleCLPC", "ApplePPM", "ApplePMGR", "pmgr", "cpm", "AppleARMPMU",
                               "AppleARMPERF", "AppleSMC", NULL };
    for (int si = 0; svcNames[si]; si++) {
        io_service_t svc = IOServiceGetMatchingService(MACH_PORT_NULL, IOServiceMatching(svcNames[si]));
        if (!svc) continue;
        CFMutableDictionaryRef pr = NULL;
        if (IORegistryEntryCreateCFProperties(svc, &pr, kCFAllocatorDefault, 0) == KERN_SUCCESS && pr) {
            NSDictionary *d = CFBridgingRelease(pr);
            [s appendFormat:S("[服务 %s] 属性 %lu 个\n"), svcNames[si], (unsigned long)d.count];
            for (NSString *k in d.allKeys) {
                id v = d[k];
                NSString *desc = nil;
                if ([v isKindOfClass:[NSData class]]) {
                    NSData *dd = (NSData *)v;
                    const uint32_t *wp = (const uint32_t *)dd.bytes;
                    NSUInteger words = dd.length / 4;
                    NSMutableString *vals = [NSMutableString string];
                    for (NSUInteger x = 0; x < words && x < 10; x++) [vals appendFormat:S(" %u"), wp[x]];
                    desc = [NSString stringWithFormat:S("<data %lu 字节:%@>"), (unsigned long)dd.length, vals];
                } else {
                    desc = [v description];
                    if (desc.length > 160) desc = [desc substringToIndex:160];
                }
                [s appendFormat:S("  %@ = %@\n"), k, desc];
            }
        }
        IOObjectRelease(svc);
    }

    // ---- 2) IOService 平面浅扫：找属性名含 voltage-states 的 ----
    [s appendString:S("\n--- IOService 平面里的 voltage-states ---\n")];
    io_registry_entry_t svcRoot = IORegistryEntryFromPath(MACH_PORT_NULL, "IOService:/");
    if (svcRoot) {
        int vis = 0;
        NSArray<NSNumber *> *dummy = nil;
        NSInteger dummyScore = -1;
        CTFreqScanTree(svcRoot, 0, 0, YES, &dummy, &dummyScore, &vis);
        IOObjectRelease(svcRoot);
    }

    // ---- 3) 系统参数 ----
    [s appendString:S("\n--- sysctl ---\n")];
    const char *sysNames[] = { "hw.cpufrequency", "hw.cpufrequency_max", "hw.cpufrequency_min",
                               "hw.perflevel0.nominal-freq", "hw.perflevel0.physicalcpu",
                               "hw.perflevel0.maxfreq", "hw.ncpu", NULL };
    for (int yi = 0; sysNames[yi]; yi++) {
        uint64_t v = 0;
        size_t sz = sizeof(v);
        if (sysctlbyname(sysNames[yi], &v, &sz, NULL, 0) == 0) {
            [s appendFormat:S("sysctl %s = %llu\n"), sysNames[yi], (unsigned long long)v];
        } else {
            [s appendFormat:S("sysctl %s = 无\n"), sysNames[yi]];
        }
    }

    if (g_ctFreqScanLog.length > 0) {
        [s appendFormat:S("\n=== 设备树里找到的频率表候选 ===\n%@"), g_ctFreqScanLog];
    }
    [s writeToFile:S("/tmp/CPUthermalFreqProbe.txt") atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    { NSData *d = [s dataUsingEncoding:NSUTF8StringEncoding]; if (d) [d writeToFile:S("/var/mobile/Library/Logs/CPUthermalFreqProbe.txt") atomically:YES]; }

}

@implementation CPUthermalCCModuleViewController

@synthesize modeValues = _modeValues;
@synthesize modeTitles = _modeTitles;
@synthesize modeSubtitles = _modeSubtitles;
@synthesize selectedIndex = _selectedIndex;

//==============================================================================
#pragma mark - Prefs Helpers
//==============================================================================


/// 读取当前功率模式值
- (NSString *)currentPowerMode {
    NSDictionary *prefs = CPUthermalReadPrefs();
    NSString *mode = prefs[S("powerMode")];
    if ([mode isKindOfClass:[NSString class]] && [mode length] > 0) {
        return mode;
    }
    return S(kCPUthermalFullPowerModeC); // 默认解除温控
}

- (BOOL)isTweakEnabled {
    return YES; // 始终启用，无需用户开关
}

- (void)saveTweakEnabled:(BOOL)enabled {
    // 已废弃：CPUthermal 始终启用，无需保存开关状态
}

/// 写入功率模式并发送通知
- (void)savePowerMode:(NSString *)mode {
    NSMutableDictionary *prefs = CPUthermalReadMutablePrefs();
    if (!prefs) prefs = [NSMutableDictionary dictionary];
    prefs[S("powerMode")] = mode ?: S(kCPUthermalFullPowerModeC);

    CPUthermalWritePrefs(prefs);
    CPUthermalPostPowerMode(mode ?: S(kCPUthermalFullPowerModeC));
    NSString *client = CPUthermalExistingExecutablePath("/usr/local/bin/CPUthermalMountClient", @[
        S("/var/jb/usr/local/bin/CPUthermalMountClient"), S("/usr/local/bin/CPUthermalMountClient")]);
    if (client.length) dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        pid_t pid = 0;
        char *args[] = {(char *)"CPUthermalMountClient", (char *)"restart-thermal-monitor", NULL};
        posix_spawn(&pid, client.fileSystemRepresentation, NULL, NULL, args, NULL);
    });
}


//==============================================================================
#pragma mark - Initialization
//==============================================================================

- (instancetype)init {
    self = [super init];
    if (self) {
        _modeValues = @[S(kCPUthermalLowPowerModeC), S(kCPUthermalFullPowerModeC)];
        _modeTitles = @[S("低功耗"), S("解除温控")];
        _modeSubtitles = @[S("更省电，机身更凉"), S("性能优先，全部满频")];

        // 读取当前设置的模式
        NSString *currentMode = [self currentPowerMode];
        _selectedIndex = [_modeValues indexOfObject:currentMode];
        if (_selectedIndex == NSNotFound) {
            _selectedIndex = [_modeValues indexOfObject:S(kCPUthermalFullPowerModeC)];
        }
    }
    return self;
}

//==============================================================================
#pragma mark - UIViewController Lifecycle
//==============================================================================

// 生成“符号 + 文字”的小图标，尺寸对齐系统图标，模板渲染 → 自动跟随浅色/深色变黑或变白
// 低功耗 = 🐢 +「低功耗」   解除温控 = 🐰 +「满频」
- (UIImage *)labeledGlyphForLowPower:(BOOL)lowPower {
    NSString *symbolName = lowPower ? S("tortoise.fill") : S("hare.fill");
    NSString *text = lowPower ? S("低功耗") : S("满频");

    UIImageSymbolConfiguration *config =
        [UIImageSymbolConfiguration configurationWithPointSize:20 weight:UIImageSymbolWeightRegular];
    UIImage *symbol = [UIImage systemImageNamed:symbolName withConfiguration:config];
    CGSize symbolSize = symbol ? symbol.size : CGSizeZero;

    NSDictionary *attrs = @{ NSFontAttributeName: [UIFont systemFontOfSize:10.0 weight:UIFontWeightMedium],
                             NSForegroundColorAttributeName: [UIColor whiteColor] };
    CGSize textSize = [text sizeWithAttributes:attrs];

    // 高度 = 图标 + 文字（留 6pt 呼吸感，不挤在一起）
    const CGFloat gap = 6.0;
    CGFloat width  = MAX(MAX(symbolSize.width, textSize.width), 30.0);
    CGFloat height = symbolSize.height + gap + textSize.height;
    CGSize size = CGSizeMake(ceil(width), ceil(height));

    UIGraphicsImageRendererFormat *format =
        [UIGraphicsImageRendererFormat formatForTraitCollection:self.traitCollection];
    UIGraphicsImageRenderer *renderer =
        [[UIGraphicsImageRenderer alloc] initWithSize:size format:format];
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        if (symbol) {
            [symbol drawInRect:CGRectMake((size.width - symbolSize.width) / 2.0, 0.0,
                                          symbolSize.width, symbolSize.height)];
        }
        [text drawAtPoint:CGPointMake((size.width - textSize.width) / 2.0, symbolSize.height + gap)
           withAttributes:attrs];
    }];
    // 模板渲染：整张图只保留形状，颜色由系统按当前外观/状态自动决定
    return [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}

// 按当前模式切换控制中心图标：低功耗 = 🐢 绿色；解除温控 = 🐰 橙色
// 形状 + 颜色双重区分，一眼就能看出当前模式
- (void)applyModeAppearance {
    BOOL lowPower = (_selectedIndex == 0);
    UIImageSymbolConfiguration *config =
        [UIImageSymbolConfiguration configurationWithPointSize:24 weight:UIImageSymbolWeightSemibold];
    UIImage *glyph = [self currentGlyphImage];   // 有实时频率就显示频率，否则回落原图标
    if (!glyph) glyph = [UIImage systemImageNamed:(lowPower ? S("tortoise.fill") : S("hare.fill")) withConfiguration:config];
    if (glyph && [self respondsToSelector:@selector(setGlyphImage:)]) {
        [self setGlyphImage:glyph];
    }
    if ([self respondsToSelector:@selector(setSelectedGlyphColor:)]) {
        [self setSelectedGlyphColor:[UIColor labelColor]];
    }
    self.title = lowPower ? S("低功耗模式") : S("解除温控模式");
}

// 系统浅色/深色切换时立刻重画图标（图标颜色跟着变黑或变白）
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection {
    [super traitCollectionDidChange:previousTraitCollection];
    if (previousTraitCollection &&
        previousTraitCollection.userInterfaceStyle != self.traitCollection.userInterfaceStyle) {
        [self applyModeAppearance];
    }
}
#pragma clang diagnostic pop

- (void)viewDidLoad {
    [super viewDidLoad];

    // 设置标题
    self.title = S("CPUthermal");

    // 设置控制中心图标（用 respondsToSelector 保护，避免私有 API 变更导致崩溃）
    [self applyModeAppearance];

    // 启动实时 CPU 频率刷新（读不到会自动回落原图标）
    [self startFrequencyTimer];
    CTFreqDumpProbe();   // 每次加载都写一份带版本标记的诊断文件
    CTFreqDumpTablesV2(); // 探针 V2：全量列出系统里所有频率表/属性（只读）

    if ([self respondsToSelector:@selector(setUseTrailingCheckmarkLayout:)]) {
        [self setUseTrailingCheckmarkLayout:YES];
    }
    if ([self respondsToSelector:@selector(setUseTallLayout:)]) {
        [self setUseTallLayout:NO];
    }
    if ([self respondsToSelector:@selector(setHideGlyphInHeader:)]) {
        [self setHideGlyphInHeader:NO];
    }
    if ([self respondsToSelector:@selector(setShouldProvideOwnPlatter:)]) {
        [self setShouldProvideOwnPlatter:NO];
    }

    // 布局 UI
    [self setupView];

}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self refreshState];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self styleMenuItemLabelsAfterLayout];
}

//==============================================================================
#pragma mark - Public
//==============================================================================

- (void)refreshState {
    [self applyModeAppearance];
    [self updateSelectedIndexFromCurrentMode];
    [self setupModeButtons];
    [self updateModuleSelectedState];
}

//==============================================================================
#pragma mark - CCUIContentModuleContentViewController
//==============================================================================

- (BOOL)shouldBeginTransitionToExpandedContentModule {
    // 恢复最早几版的行为：长按由控制中心展开原生面板，面板里可以直接选择模式
    _pendingModeMenu = NO;      // 面板要展开了，取消兜底菜单
    [self updateSelectedIndexFromCurrentMode];
    [self setupModeButtons];
    return YES;
}

- (void)willTransitionToExpandedContentMode:(BOOL)animated {
    [super willTransitionToExpandedContentMode:animated];
    _pendingModeMenu = NO;   // 原生面板已展开，取消兜底菜单
    _didExpand = YES;
    // 展开时刷新菜单
    [self refreshState];
}

- (CGFloat)preferredExpandedContentHeight {
    return kCPUthermalCCPreferredExpandedHeight;
}

- (CGFloat)preferredExpandedContentWidth {
    return [self availableExpandedContentWidth];
}

- (BOOL)providesOwnPlatter {
    return NO;
}


//==============================================================================
#pragma mark - Setup
//==============================================================================

- (void)setupView {
    [self updateSelectedIndexFromCurrentMode];

    // 设置菜单项
    [self setupModeButtons];

    // 应用当前选中状态
    [self updateModuleSelectedState];
}

- (void)setupModeButtons {
    NSUInteger itemCount = MIN(self.modeValues.count, self.modeTitles.count);

    NSMutableArray *items = [NSMutableArray arrayWithCapacity:itemCount];
    for (NSUInteger i = 0; i < itemCount; i++) {
        BOOL isSelected = ((NSInteger)i == self.selectedIndex);
        NSString *title = self.modeTitles[i];
        NSString *subtitle = i < self.modeSubtitles.count ? self.modeSubtitles[i] : S("");

        NSString *identifier = S("cpu-item-");
        identifier = [identifier stringByAppendingFormat:S("%lu"), (unsigned long)i];
        __weak typeof(self) weakSelf = self;
        NSInteger itemIndex = (NSInteger)i;
        CCUIMenuModuleItem *item = [[CCUIMenuModuleItem alloc] initWithTitle:title identifier:identifier handler:^{
            [weakSelf selectPowerModeAtIndex:itemIndex];
        }];
        if (!item) {
            continue;
        }
        if ([item respondsToSelector:@selector(setSubtitle:)]) {
            [item setSubtitle:subtitle];
        }
        if ([item respondsToSelector:@selector(setSelected:)]) {
            [item setSelected:isSelected];
        }
        // 行图标固定黑/白（由系统浅色深色决定），不带任何彩色
        if ([item respondsToSelector:@selector(setSelectedGlyphColor:)]) {
            [item setSelectedGlyphColor:[UIColor labelColor]];
        }


        [items addObject:item];
    }

    if ([self respondsToSelector:@selector(setMinimumMenuItems:)]) {
        [self setMinimumMenuItems:(NSInteger)itemCount];
    }
    if ([self respondsToSelector:@selector(setVisibleMenuItems:)]) {
        [self setVisibleMenuItems:(NSInteger)itemCount];
    }

    // 父类 setMenuItems: 有 respondsToSelector 兜底
    if ([self respondsToSelector:@selector(setMenuItems:)]) {
        self.menuItems = items;
    }

    [self styleMenuItemLabelsAfterLayout];
}

- (CGFloat)availableExpandedContentWidth {
    CGFloat width = kCPUthermalCCPreferredExpandedWidth;
    UIScreen *screen = [UIScreen mainScreen];
    CGFloat screenWidth = CGRectGetWidth(screen.bounds);
    if (screenWidth > 0) {
        width = MIN(width, screenWidth - (kCPUthermalCCMinimumScreenMargin * 2.0));
    }
    return MAX(width, 220.0);
}

- (void)styleMenuItemLabelsAfterLayout {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.view layoutIfNeeded];
        [self styleMenuItemLabelsInView:self.view];
    });
}

- (BOOL)isModeTitle:(NSString *)text {
    if (![text isKindOfClass:[NSString class]] || [text length] == 0) {
        return NO;
    }
    for (NSString *title in self.modeTitles) {
        if ([text isEqualToString:title]) {
            return YES;
        }
    }
    return NO;
}

- (BOOL)isModeSubtitle:(NSString *)text {
    if (![text isKindOfClass:[NSString class]] || [text length] == 0) {
        return NO;
    }
    for (NSString *subtitle in self.modeSubtitles) {
        if ([text isEqualToString:subtitle]) {
            return YES;
        }
    }
    return NO;
}

- (void)applyCompactMenuInsetsToLabel:(UILabel *)label inMenuItemView:(UIView *)menuItemView {
    if (!label || !menuItemView || !label.superview || CGRectGetWidth(menuItemView.bounds) <= 0) {
        return;
    }

    UIView *labelContainer = label.superview;
    CGRect labelFrame = label.frame;
    CGPoint labelOriginInItem = [labelContainer convertPoint:labelFrame.origin toView:menuItemView];
    CGFloat maxLabelWidth = CGRectGetWidth(menuItemView.bounds) - kCPUthermalCCMenuLeadingInset - kCPUthermalCCMenuTrailingInset;
    if (maxLabelWidth <= 0) {
        return;
    }

    CGFloat adjustedMinX = MAX(labelOriginInItem.x, kCPUthermalCCMenuLeadingInset);
    CGFloat adjustedWidth = MIN(CGRectGetWidth(labelFrame), maxLabelWidth);
    if (adjustedMinX + adjustedWidth > CGRectGetWidth(menuItemView.bounds) - kCPUthermalCCMenuTrailingInset) {
        adjustedWidth = CGRectGetWidth(menuItemView.bounds) - kCPUthermalCCMenuTrailingInset - adjustedMinX;
    }
    if (adjustedWidth <= 0) {
        return;
    }

    CGPoint adjustedOrigin = [menuItemView convertPoint:CGPointMake(adjustedMinX, labelOriginInItem.y) toView:labelContainer];
    labelFrame.origin.x = adjustedOrigin.x;
    labelFrame.size.width = adjustedWidth;
    label.frame = labelFrame;
}

- (void)styleMenuItemLabelsInView:(UIView *)view {
    if (!view) {
        return;
    }

    NSString *className = NSStringFromClass([view class]);
    BOOL isMenuItemView = [className containsString:S("MenuModuleItem")];
    if (isMenuItemView) {
        if ([view respondsToSelector:@selector(setUseTrailingCheckmarkLayout:)]) {
            [view setUseTrailingCheckmarkLayout:YES];
        }
        if ([view respondsToSelector:@selector(setUseTrailingInset:)]) {
            [view setUseTrailingInset:YES];
        }
        if ([view respondsToSelector:@selector(setIndentation:)]) {
            [view setIndentation:kCPUthermalCCMenuLeadingInset];
        }

        UILabel *titleLabel = nil;
        UILabel *subtitleLabel = nil;
        if ([view respondsToSelector:@selector(titleLabel)]) {
            titleLabel = [view titleLabel];
        }
        if ([view respondsToSelector:@selector(subtitleLabel)]) {
            subtitleLabel = [view subtitleLabel];
        }

        NSMutableArray<UILabel *> *labels = [NSMutableArray array];
        if (titleLabel) {
            [labels addObject:titleLabel];
        }
        if (subtitleLabel && subtitleLabel != titleLabel) {
            [labels addObject:subtitleLabel];
        }
        for (UIView *subview in view.subviews) {
            if ([subview isKindOfClass:[UILabel class]] && ![labels containsObject:(UILabel *)subview]) {
                [labels addObject:(UILabel *)subview];
            }
            for (UIView *nestedSubview in subview.subviews) {
                if ([nestedSubview isKindOfClass:[UILabel class]] && ![labels containsObject:(UILabel *)nestedSubview]) {
                    [labels addObject:(UILabel *)nestedSubview];
                }
            }
        }

        for (UILabel *label in labels) {
            if (![label isKindOfClass:[UILabel class]]) {
                continue;
            }
            BOOL isTitle = [self isModeTitle:label.text];
            BOOL isSubtitle = [self isModeSubtitle:label.text];
            if (!isTitle && !isSubtitle) {
                continue;
            }
            label.textAlignment = NSTextAlignmentLeft;
            label.numberOfLines = 1;
            label.lineBreakMode = NSLineBreakByTruncatingTail;
            label.adjustsFontSizeToFitWidth = YES;
            label.minimumScaleFactor = 0.82;
            if (isTitle) {
                label.font = [UIFont systemFontOfSize:kCPUthermalCCTitleFontSize weight:UIFontWeightSemibold];
                label.textColor = [UIColor labelColor];
            } else {
                label.font = [UIFont systemFontOfSize:kCPUthermalCCSubtitleFontSize weight:UIFontWeightRegular];
                label.textColor = [UIColor labelColor];
            }
            [self applyCompactMenuInsetsToLabel:label inMenuItemView:view];
        }
    }

    for (UIView *subview in view.subviews) {
        [self styleMenuItemLabelsInView:subview];
    }
}

//==============================================================================
#pragma mark - Button Actions
//==============================================================================

- (void)updateSelectedIndexFromCurrentMode {
    NSString *currentMode = [self currentPowerMode];
    NSInteger newIndex = [self.modeValues indexOfObject:currentMode];
    if (newIndex == NSNotFound) {
        newIndex = [self.modeValues indexOfObject:S(kCPUthermalFullPowerModeC)];
    }
    _selectedIndex = newIndex;
}

// 取控制中心控件本体（那个方块视图）
- (UIView *)cpuTileButtonView {
    if ([self respondsToSelector:NSSelectorFromString(S("buttonView"))]) {
        UIView *tile = [self buttonView];
        if ([tile isKindOfClass:[UIView class]]) {
            return tile;
        }
    }
    return nil;
}

// 给控件本体挂长按识别（只挂一次）
- (void)setupTileLongPressIfNeeded {
    if (_longPressAttached) {
        return;
    }
    UIView *tile = [self cpuTileButtonView];
    if (!tile) {
        return;
    }
    UILongPressGestureRecognizer *press =
        [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleTileLongPress:)];
    press.minimumPressDuration = 0.4;
    press.cancelsTouchesInView = NO;   // 不影响单击
    [tile addGestureRecognizer:press];
    _longPressAttached = YES;
}

// 长按：震动 + 弹出模式说明
- (void)handleTileLongPress:(UILongPressGestureRecognizer *)recognizer {
    if (recognizer.state != UIGestureRecognizerStateBegan) {
        return;
    }

    _suppressNextTap = YES;   // 松手时不要被当成单击而误切模式
    _pendingModeMenu = YES;

    [self playHapticFeedback];

    __weak typeof(self) weakSelf = self;

    // 安全清理：长按标记最多保留 1.2 秒，避免影响后续单击
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf) {
            strongSelf->_suppressNextTap = NO;
        }
    });

    // 优先展开控制中心原生面板（可在面板里选择模式、看到“更省电”描述）；
    // 若系统没展开（个别机型），0.55 秒后兜底弹出同样的可选菜单
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf || !strongSelf->_pendingModeMenu || strongSelf->_didExpand) {
            return;
        }
        strongSelf->_pendingModeMenu = NO;
        strongSelf->_suppressNextTap = NO;
        [strongSelf showModeMenu];
    });
}

- (void)playHapticFeedback {
    UIImpactFeedbackGenerator *generator =
        [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [generator prepare];
    [generator impactOccurred];
}

// 长按弹出的“模式菜单”：每个模式一行，点哪行切哪个
- (void)showModeMenu {
    [self updateSelectedIndexFromCurrentMode];

    NSUInteger count = MIN(self.modeTitles.count, self.modeSubtitles.count);
    if (count == 0) {
        return;
    }

    UIAlertController *sheet =
        [UIAlertController alertControllerWithTitle:S("CPUthermal 模式")
                                           message:S("点选要用的模式")
                                    preferredStyle:UIAlertControllerStyleActionSheet];

    for (NSUInteger i = 0; i < count; i++) {
        BOOL isCurrent = ((NSInteger)i == _selectedIndex);
        NSString *rowTitle = [NSString stringWithFormat:@"%@%@ —— %@",
                                                        isCurrent ? S("● ") : S("○ "),
                                                        self.modeTitles[i],
                                                        self.modeSubtitles[i]];
        NSInteger targetIndex = (NSInteger)i;
        __weak typeof(self) weakSelf = self;
        [sheet addAction:[UIAlertAction actionWithTitle:rowTitle
                                                style:UIAlertActionStyleDefault
                                              handler:^(UIAlertAction *action) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf) {
                return;
            }
            [strongSelf selectPowerModeAtIndex:targetIndex dismissAfterSelection:NO];
            [strongSelf applyModeAppearance];
            [strongSelf playHapticFeedback];
        }]];
    }

    [sheet addAction:[UIAlertAction actionWithTitle:S("取消")
                                             style:UIAlertActionStyleCancel
                                           handler:nil]];

    // 大屏 / iPad 上用 popover 呈现，避免崩溃
    UIViewController *anchor = [self cpuPresentationHosts].firstObject;
    if (anchor && anchor.view) {
        sheet.popoverPresentationController.sourceView = anchor.view;
        sheet.popoverPresentationController.sourceRect = anchor.view.bounds;
    }

    // 按“可见窗口优先”的顺序逐个尝试呈现，失败自动换下一个
    [self presentMenu:sheet hosts:[self cpuPresentationHosts] index:0];
}

// 候选承载者：优先当前可见窗口的根控制器（控制中心模块自身的视图承载不了弹窗）
- (NSArray<UIViewController *> *)cpuPresentationHosts {
    NSMutableArray<UIViewController *> *hosts = [NSMutableArray array];

    UIViewController *(^topMost)(UIViewController *) = ^UIViewController *(UIViewController *vc) {
        UIViewController *current = vc;
        while (current.presentedViewController) {
            current = current.presentedViewController;
        }
        return current;
    };

    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if (![scene isKindOfClass:[UIWindowScene class]]) {
                continue;
            }
            for (UIWindow *window in ((UIWindowScene *)scene).windows) {
                if (window.isKeyWindow && window.rootViewController) {
                    [hosts addObject:topMost(window.rootViewController)];
                }
            }
        }
    } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        for (UIWindow *window in [UIApplication sharedApplication].windows) {
            if (window.isKeyWindow && window.rootViewController) {
                [hosts addObject:topMost(window.rootViewController)];
            }
        }
#pragma clang diagnostic pop
    }

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        if (window.rootViewController && !window.hidden) {
            UIViewController *top = topMost(window.rootViewController);
            if (![hosts containsObject:top]) {
                [hosts addObject:top];
            }
        }
    }
#pragma clang diagnostic pop

    UIView *tile = [self cpuTileButtonView];
    if (tile.window.rootViewController) {
        UIViewController *top = topMost(tile.window.rootViewController);
        if (![hosts containsObject:top]) {
            [hosts addObject:top];
        }
    }

    if (![hosts containsObject:self]) {
        [hosts addObject:self];
    }
    return hosts;
}

// 逐个尝试呈现；若前一个没成功，自动用下一个候选
- (void)presentMenu:(UIAlertController *)menu hosts:(NSArray<UIViewController *> *)hosts index:(NSUInteger)index {
    if (index >= hosts.count) {
        return;
    }
    UIViewController *host = hosts[index];
    if (host.presentedViewController) {
        [self presentMenu:menu hosts:hosts index:index + 1];
        return;
    }

    [host presentViewController:menu animated:YES completion:nil];

    __weak typeof(self) weakSelf = self;
    __weak UIViewController *weakHost = host;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        UIViewController *strongHost = weakHost;
        if (!strongSelf || !strongHost) {
            return;
        }
        // 没挂上 → 换下一个候选再试
        if (strongHost.presentedViewController != menu) {
            [strongSelf presentMenu:menu hosts:hosts index:index + 1];
        }
    });
}

// 单击控件 → 切换模式（控制中心把“单击”送到这里）
- (void)buttonTapped:(id)arg forEvent:(id)event {
    (void)arg;

    // 长按后松手：不切换模式，让 shouldBegin... 去展开面板
    if (_suppressNextTap) {
        _lastInputWasTap = NO;
        return;
    }

    _lastInputWasTap = YES;
    if ([event isKindOfClass:[UIEvent class]]) {
        UITouch *touch = ((UIEvent *)event).allTouches.allObjects.firstObject;
        if (touch && touch.tapCount <= 0) {
            _lastInputWasTap = NO;
            return;
        }
    }

    [self updateSelectedIndexFromCurrentMode];
    NSInteger itemCount = (NSInteger)self.modeValues.count;
    if (itemCount <= 0) {
        return;
    }

    NSInteger nextIndex = (self.selectedIndex + 1) % itemCount;
    [self selectPowerModeAtIndex:nextIndex dismissAfterSelection:NO];
    [self applyModeAppearance];

    // 切换生效 → 震动反馈
    [self playHapticFeedback];

    // 万一单击也把面板唤出来了，稍后自动收起（不影响长按）
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.45 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf && strongSelf->_didExpand) {
            strongSelf->_didExpand = NO;
            [strongSelf dismissViewControllerAnimated:YES completion:nil];
        }
    });
}

- (void)toggleTweakEnabled {
    // 已废弃：CPUthermal 始终启用，无需切换
}

- (void)buttonModeTapped:(CCUIMenuModuleItem *)sender {
    NSInteger index = [self.menuItems indexOfObject:sender];
    [self selectPowerModeAtIndex:index];
}

- (void)selectPowerModeAtIndex:(NSInteger)index {
    [self selectPowerModeAtIndex:index dismissAfterSelection:YES];
}

- (void)selectPowerModeAtIndex:(NSInteger)index dismissAfterSelection:(BOOL)dismissAfterSelection {
    if (index == NSNotFound || index < 0 || index >= (NSInteger)self.modeValues.count) {
        return;
    }

    _selectedIndex = index;
    NSString *modeValue = self.modeValues[index];

    // 写入偏好设置并通知 tweak
    [self savePowerMode:modeValue];

    // 刷新 UI（含控制中心图标上的小注）
    [self setupModeButtons];
    [self updateModuleSelectedState];
    [self applyModeAppearance];
    [self refreshFrequencyGlyph];   // 切模式后立刻换图标上的数字

    if (!dismissAfterSelection) {
        return;
    }

    // 短暂延迟后折叠
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:nil];
    });
}

- (void)updateModuleSelectedState {
    // 关键：不上报“已开启/选中”。一旦上报，系统会给控件套“开启样式”
    // （白底 + 深色图标），看起来就和旁边不一样了。
    if ([self respondsToSelector:@selector(setSelected:)]) {
        [self setSelected:NO];
    }
}

//==============================================================================
#pragma mark - Properties
//==============================================================================

- (NSArray<NSString *> *)modeValues {
    return _modeValues;
}

- (void)setModeValues:(NSArray<NSString *> *)modeValues {
    _modeValues = [modeValues copy];
    [self setupModeButtons];
}


//==============================================================================
#pragma mark - 频率图标（把上面那个图片换成实时频率）
//==============================================================================
- (UIImage *)glyphWithText:(NSString *)topText bottomText:(NSString *)bottomText {
    // 上排 12pt / 下排 10pt（按历史版本实测还原）；字重 = 历史版本一致的 Semibold / Medium
    CGFloat topSize = 12.0;
    NSDictionary *topAttrs = @{ NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:topSize weight:UIFontWeightSemibold],
                                NSForegroundColorAttributeName: [UIColor whiteColor] };
    while (topSize > 9.5 && [topText sizeWithAttributes:topAttrs].width > 56.0) {
        topSize -= 0.5;
        topAttrs = @{ NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:topSize weight:UIFontWeightSemibold],
                      NSForegroundColorAttributeName: [UIColor whiteColor] };
    }
    NSDictionary *botAttrs = @{ NSFontAttributeName: [UIFont systemFontOfSize:10.0 weight:UIFontWeightMedium],
                                NSForegroundColorAttributeName: [UIColor whiteColor] };
    // 两行按「墨迹高度」排 → 行间距与上下留白都对称
    CGRect ti = [topText boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX) options:NSStringDrawingUsesDeviceMetrics attributes:topAttrs context:nil];
    CGRect bi = [bottomText boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX) options:NSStringDrawingUsesDeviceMetrics attributes:botAttrs context:nil];
    if (ti.size.height <= 0.0) { CGSize z = [topText sizeWithAttributes:topAttrs]; ti = CGRectMake(0, 0, z.width, z.height); }
    if (bi.size.height <= 0.0) { CGSize z = [bottomText sizeWithAttributes:botAttrs]; bi = CGRectMake(0, 0, z.width, z.height); }
    const CGFloat gap = 9.0;
    CGFloat width  = MAX(MAX(ti.size.width, bi.size.width), 30.0);
    CGFloat height = ti.size.height + gap + bi.size.height;
    CGSize size = CGSizeMake(ceil(width), ceil(height + 6.5));   // 底下多留 6.5pt → 整块比居中再往上移 3.2pt（与历史截图一致）
    UIGraphicsImageRendererFormat *format =
        [UIGraphicsImageRendererFormat formatForTraitCollection:self.traitCollection];
    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:size format:format];
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        CGFloat y = 0.0;                             // 顶部对齐 → 整块上移
        [topText    drawAtPoint:CGPointMake(round((size.width - ti.size.width) / 2.0), y - ti.origin.y) withAttributes:topAttrs];
        y += ti.size.height + gap;
        [bottomText drawAtPoint:CGPointMake(round((size.width - bi.size.width) / 2.0), y - bi.origin.y) withAttributes:botAttrs];
    }];
    return [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}

- (UIImage *)glyphWithTopText:(NSString *)topText {
    return [self glyphWithText:topText bottomText:((_selectedIndex == 0) ? S("低功耗") : S("满频"))];
}

// 当前模式的文字（中排）
- (NSString *)modeGlyphText {
    return (_selectedIndex == 0) ? S("低功耗") : S("满频");
}

// 三行图标：上 = 实时频率（大、等宽数字）/ 中 = 模式文字 / 下 = 该模式上限（小一号）
// 上排文字过宽时自动缩字（12pt 起，每 0.5pt 递减到 8.5pt）
- (UIImage *)glyphWithTopText:(NSString *)topText middleText:(NSString *)midText bottomText:(NSString *)botText {
    // 上排（实时频率）: 10pt / 中排（模式文字）: 11pt / 下排（当前最高档）: 13pt
    NSDictionary *topAttrs = @{ NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:10.0 weight:UIFontWeightMedium],
                                NSForegroundColorAttributeName: [UIColor whiteColor] };
    NSDictionary *midAttrs = @{ NSFontAttributeName: [UIFont systemFontOfSize:11.0 weight:UIFontWeightMedium],
                                NSForegroundColorAttributeName: [UIColor whiteColor] };
    CGFloat botSize = 13.0;
    NSDictionary *botAttrs = @{ NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:botSize weight:UIFontWeightSemibold],
                                NSForegroundColorAttributeName: [UIColor colorWithWhite:1.0 alpha:0.85] };
    while (botSize > 8.5 && [botText sizeWithAttributes:botAttrs].width > 56.0) {
        botSize -= 0.5;
        botAttrs = @{ NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:botSize weight:UIFontWeightSemibold],
                      NSForegroundColorAttributeName: [UIColor colorWithWhite:1.0 alpha:0.85] };
    }
    // 三行按「墨迹高度」（实际字形）排 → 行与行之间空白完全相等，视觉对称
    CGRect ti = [topText boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX) options:NSStringDrawingUsesDeviceMetrics attributes:topAttrs context:nil];
    CGRect mi = [midText boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX) options:NSStringDrawingUsesDeviceMetrics attributes:midAttrs context:nil];
    CGRect bi = [botText boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, CGFLOAT_MAX) options:NSStringDrawingUsesDeviceMetrics attributes:botAttrs context:nil];
    if (ti.size.height <= 0.0) { CGSize z = [topText sizeWithAttributes:topAttrs]; ti = CGRectMake(0, 0, z.width, z.height); }
    if (mi.size.height <= 0.0) { CGSize z = [midText sizeWithAttributes:midAttrs]; mi = CGRectMake(0, 0, z.width, z.height); }
    if (bi.size.height <= 0.0) { CGSize z = [botText sizeWithAttributes:botAttrs]; bi = CGRectMake(0, 0, z.width, z.height); }
    const CGFloat gap = 3.5;
    CGFloat width  = MAX(MAX(MAX(ti.size.width, mi.size.width), bi.size.width), 30.0);
    CGFloat height = ti.size.height + gap + mi.size.height + gap + bi.size.height;
    CGSize size = CGSizeMake(ceil(width), ceil(height));
    UIGraphicsImageRendererFormat *format =
        [UIGraphicsImageRendererFormat formatForTraitCollection:self.traitCollection];
    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:size format:format];
    UIImage *image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        CGFloat y = (size.height - height) / 2.0;   // 上下留白相等
        [topText drawAtPoint:CGPointMake(round((size.width - ti.size.width) / 2.0), y - ti.origin.y) withAttributes:topAttrs];
        y += ti.size.height + gap;
        [midText drawAtPoint:CGPointMake(round((size.width - mi.size.width) / 2.0), y - mi.origin.y) withAttributes:midAttrs];
        y += mi.size.height + gap;
        [botText drawAtPoint:CGPointMake(round((size.width - bi.size.width) / 2.0), y - bi.origin.y) withAttributes:botAttrs];
    }];
    return [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}
- (UIImage *)frequencyGlyphForMHz:(double)mhz {
    return [self glyphWithTopText:[NSString stringWithFormat:S("%.0f"), mhz]];
}
// 当前模式对应的「频率上限」：满频=100%；低功耗按省电强度 35/45/55%，
// 再取最接近的真实档位（P 核档位表），所以显示的都是真实频率
- (int)cappedFrequencyMHz {
    NSDictionary *prefs = CPUthermalReadPrefs();
    NSInteger strength = 1;
    id v = prefs ? prefs[S("lowPowerStrength")] : nil;
    if ([v respondsToSelector:@selector(integerValue)]) strength = [v integerValue];
    int percent = (strength == 0) ? 35 : ((strength == 2) ? 55 : 45);
    if (_selectedIndex != 0) percent = 100;                    // 解除温控 = 不限制

    NSArray<NSNumber *> *ladder = CTFreqTableMatching(17);
    if (ladder.count == 0) {
        ladder = @[ @576, @1092, @1344, @1584, @1824, @2064, @2304, @2544, @2724, @2904,
                    @3084, @3264, @3444, @3564, @3684, @3732, @3780 ];
    }
    double maxMHz = [ladder.lastObject doubleValue];
    if (percent >= 100) return (int)maxMHz;
    double target = percent / 100.0 * maxMHz;
    double bestDelta = 1e9;
    int bestMHz = (int)maxMHz;
    for (NSNumber *n in ladder) {
        double d = fabs(n.doubleValue - target);
        if (d < bestDelta) { bestDelta = d; bestMHz = (int)n.doubleValue; }
    }
    return bestMHz;
}

// 当前模式要显示的数字：从系统频率表实时读取的最高档
//   解除温控（_selectedIndex == 1）→ 大核频率表最高档（本机 3780）
//   低功耗  （_selectedIndex == 0）→ 小核频率表最高档（本机 2112）
- (int)systemDisplayMHz {
    int states = (_selectedIndex == 0) ? 5 : 17;
    int mhz = CTFreqSystemMaxMHz(states);
    if (mhz > 0) return mhz;
    return (_selectedIndex == 0) ? kCTSystemLowPowerMHz : kCTSystemFullMHz;   // 读不到才兜底
}

- (UIImage *)currentGlyphImage {
    // 还没读到实时频率时：上排先显示 --，中排模式文字，下排该模式上限
    return [self glyphWithTopText:[NSString stringWithFormat:S("%d"), [self systemDisplayMHz]]];
}

// 固定显示一个数字（变了才重画，低功耗模式下不读传感器、不费电）
- (void)applyFixedGlyphMHz:(int)mhz {
    if (g_ctLastMHz > 0.0 && fabs(g_ctLastMHz - (double)mhz) < 1.0) return;
    g_ctLastMHz = (double)mhz;
    UIImage *img = [self frequencyGlyphForMHz:(double)mhz];
    if (img && [self respondsToSelector:@selector(setGlyphImage:)]) [self setGlyphImage:img];
}

// 每秒刷新一次（值没变就不重画，省电）：
//   上排 = 实时频率（最近 5 秒内的峰值，会跳动）
//   中排 = 当前模式文字（满频 / 低功耗）
//   下排 = 该模式上限（从系统频率表实时读到的最高档，3780 / 2112）
- (void)refreshFrequencyGlyph {
    [self refreshPeakGlyph];
}

// 上排画实时频率（最近 5 秒内出现过的最高值，会跳动）
// 中排画模式文字，下排画该模式上限（从系统频率表实时读到的最高档）
- (void)applyPeakGlyphMHz:(double)peak capMHz:(int)cap {
    // 显示**系统实时的最高值**：每秒读一次「这一秒 CPU 实际用到过的最高档」，原样显示
    int shown = (peak > 0.0) ? (int)peak : cap;
    static double lastStamp = -1.0;
    double stamp = (double)shown * 10.0 + (double)_selectedIndex;
    if (lastStamp >= 0.0 && fabs(lastStamp - stamp) < 0.5) return;   // 没变就不重画
    lastStamp = stamp;
    UIImage *img = [self glyphWithTopText:[NSString stringWithFormat:S("%d"), shown]];
    if (img && [self respondsToSelector:@selector(setGlyphImage:)]) [self setGlyphImage:img];
}

// 解除温控模式：每秒读一次真实大核频率，上排显示「峰值/上限」
// （发热被温控压住时，峰值会明显掉下来，一眼就能看出实际能跑到多少）
- (void)refreshPeakGlyph {
    if (_peakModeIndex != _selectedIndex) {   // 换模式了 → 峰值重新开始算
        _peakModeIndex = _selectedIndex;
        _peakMHz = 0.0;
        _peakAt = 0.0;
    }
    int cap = [self systemDisplayMHz];
    double mhz = 0.0;
    if (CTFreqReadMHz(&mhz)) {
        _freqFail = 0;
        // 原样显示系统这一秒报出的频率（不做任何平滑、不取历史峰值）
        _peakMHz = mhz;
        _peakAt = [NSDate timeIntervalSinceReferenceDate];
        [self applyPeakGlyphMHz:mhz capMHz:cap];
        return;
    }
    _freqFail++;
    if (_freqFail >= 3) {
        CTFreqDumpProbe();
        NSString *code = [NSString stringWithFormat:S("E%d"), (int)g_ctFreqErrCode];
        NSString *info = [NSString stringWithFormat:S("c%lds%d"),
                          (long)g_ctFreqRelChans, g_ctFreqMaxStates];
        UIImage *img = [self glyphWithText:code bottomText:info];
        if (img && [self respondsToSelector:@selector(setGlyphImage:)]) [self setGlyphImage:img];
    }
}
- (void)startFrequencyTimer {
    if (_freqTimer) return;
    dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    if (!timer) return;
    _freqTimer = timer;
    dispatch_source_set_timer(timer,
                              dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                              (uint64_t)(1.0 * NSEC_PER_SEC),
                              (uint64_t)(200 * NSEC_PER_MSEC));
    __weak typeof(self) weakSelf = self;
    dispatch_source_set_event_handler(timer, ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf) [strongSelf refreshFrequencyGlyph];
    });
    dispatch_resume(timer);
}

- (NSArray<NSString *> *)modeTitles {
    return _modeTitles;
}

- (void)setModeTitles:(NSArray<NSString *> *)modeTitles {
    _modeTitles = [modeTitles copy];
    [self setupModeButtons];
}

- (NSArray<NSString *> *)modeSubtitles {
    return _modeSubtitles;
}

- (void)setModeSubtitles:(NSArray<NSString *> *)modeSubtitles {
    _modeSubtitles = [modeSubtitles copy];
    [self setupModeButtons];
}

- (NSInteger)selectedIndex {
    return _selectedIndex;
}

- (void)setSelectedIndex:(NSInteger)selectedIndex {
    _selectedIndex = selectedIndex;
    [self setupModeButtons];
}

@end
