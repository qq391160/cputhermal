#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <notify.h>
#import <CPUthermalPaths.h>

@interface CPUthermalAppListController : PSListController <UISearchResultsUpdating>
@property(nonatomic,strong) NSArray<NSDictionary *> *allApps;
@property(nonatomic,copy) NSString *searchTerm;
@property(nonatomic,strong) UISearchController *searchController;
@end

static UIImage *CPUthermalIconForApp(NSString *bundleID, NSString *bundlePath);

@interface CPUthermalAppListController ()
- (BOOL)bundleIsHidden:(NSString *)bundleID;
@end

@implementation CPUthermalAppListController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = S("指定应用低功耗");
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.searchController.searchResultsUpdater = self;
    self.searchController.obscuresBackgroundDuringPresentation = NO;
    self.searchController.searchBar.placeholder = S("名称或 Bundle ID");
    self.navigationItem.searchController = self.searchController;
    self.navigationItem.hidesSearchBarWhenScrolling = NO;
    self.definesPresentationContext = YES;
}

- (NSString *)stringFromObject:(id)object selectors:(NSArray<NSString *> *)selectors {
    for (NSString *name in selectors) {
        SEL selector = NSSelectorFromString(name);
        if (![object respondsToSelector:selector]) continue;
        id value = ((id (*)(id, SEL))objc_msgSend)(object, selector);
        if ([value isKindOfClass:[NSString class]] && [value length] > 0) return value;
    }
    return nil;
}

- (id)applicationProxyForBundleID:(NSString *)bundleID {
    @try {
        Class proxyClass = NSClassFromString(S("LSApplicationProxy"));
        SEL proxySel = NSSelectorFromString(S("applicationProxyForIdentifier:"));
        if (proxyClass && [proxyClass respondsToSelector:proxySel] && bundleID.length) return ((id (*)(id, SEL, NSString *))objc_msgSend)(proxyClass, proxySel, bundleID);
    } @catch (__unused NSException *exception) {}
    return nil;
}

// 系统内部组件/隐藏 App（桌面上看不到的那种）一律不列进来
- (BOOL)bundleIsHidden:(NSString *)bundleID {
    id proxy = [self applicationProxyForBundleID:bundleID];
    @try {
        SEL hiddenSel = NSSelectorFromString(S("isHidden"));
        if (proxy && [proxy respondsToSelector:hiddenSel]) return ((BOOL (*)(id, SEL))objc_msgSend)(proxy, hiddenSel);
        // 不能从桌面启动的（各种 ViewService / WidgetRenderer / XXXUI / WebSheet 之类）一律不算 App
        SEL launchSel = NSSelectorFromString(S("isLaunchable"));
        if (proxy && [proxy respondsToSelector:launchSel] && !((BOOL (*)(id, SEL))objc_msgSend)(proxy, launchSel)) return YES;
        // 类型为 Internal 的系统内部组件也不要
        SEL typeSel = NSSelectorFromString(S("applicationType"));
        if (proxy && [proxy respondsToSelector:typeSel]) {
            id appType = ((id (*)(id, SEL))objc_msgSend)(proxy, typeSel);
            if ([appType isKindOfClass:[NSString class]] && [[(NSString *)appType lowercaseString] containsString:S("internal")]) return YES;
        }
    } @catch (__unused NSException *exception) {}
    return NO;
}

- (void)addApplicationAtPath:(NSString *)appPath toMap:(NSMutableDictionary *)map {
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[appPath stringByAppendingPathComponent:S("Info.plist")]];
    NSString *bundleID = info[S("CFBundleIdentifier")];
    if (![bundleID isKindOfClass:[NSString class]] || bundleID.length == 0) return;
    if ([self bundleIsHidden:bundleID]) return;
    NSString *name = [self stringFromObject:[self applicationProxyForBundleID:bundleID] selectors:@[S("localizedName"),S("itemName"),S("localizedShortName")]];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = info[S("CFBundleDisplayName")];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = info[S("CFBundleName")];
    if (![name isKindOfClass:[NSString class]] || name.length == 0) name = bundleID;
    map[bundleID] = @{S("id"):bundleID, S("name"):name, S("path"):appPath ?: S("")};
}

- (NSArray<NSDictionary *> *)enumerateApplications {
    NSMutableDictionary *map = [NSMutableDictionary dictionary];
    @try {
        Class workspaceClass = NSClassFromString(S("LSApplicationWorkspace"));
        id workspace = [workspaceClass respondsToSelector:NSSelectorFromString(S("defaultWorkspace"))] ? ((id (*)(id, SEL))objc_msgSend)(workspaceClass, NSSelectorFromString(S("defaultWorkspace"))) : nil;
        id applications = [workspace respondsToSelector:NSSelectorFromString(S("allApplications"))] ? ((id (*)(id, SEL))objc_msgSend)(workspace, NSSelectorFromString(S("allApplications"))) : nil;
        if ([applications isKindOfClass:[NSArray class]]) for (id proxy in applications) {
            NSString *bundleID = [self stringFromObject:proxy selectors:@[S("applicationIdentifier"),S("bundleIdentifier")]];
            if (bundleID.length == 0) continue;
            if ([self bundleIsHidden:bundleID]) continue;
            NSString *name = [self stringFromObject:proxy selectors:@[S("localizedName"),S("itemName"),S("localizedShortName")]] ?: bundleID;
            NSString *bundlePath = S("");
            SEL urlSel = NSSelectorFromString(S("bundleURL"));
            if ([proxy respondsToSelector:urlSel]) {
                id url = ((id (*)(id, SEL))objc_msgSend)(proxy, urlSel);
                if ([url isKindOfClass:[NSURL class]]) bundlePath = ((NSURL *)url).path ?: S("");
            }
            map[bundleID] = @{S("id"):bundleID, S("name"):name, S("path"):bundlePath};
        }
    } @catch (__unused NSException *exception) {}
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *root in @[S("/var/mobile/Containers/Bundle/Application"), S("/var/containers/Bundle/Application"), S("/Applications"), S("/System/Applications")]) {
        for (NSString *child in [fm contentsOfDirectoryAtPath:root error:nil] ?: @[]) {
            NSString *full = [root stringByAppendingPathComponent:child];
            if ([[child pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) {
                [self addApplicationAtPath:full toMap:map];
                continue;
            }
            for (NSString *entry in [fm contentsOfDirectoryAtPath:full error:nil] ?: @[]) if ([[entry pathExtension] caseInsensitiveCompare:S("app")] == NSOrderedSame) [self addApplicationAtPath:[full stringByAppendingPathComponent:entry] toMap:map];
        }
    }
    return [map allValues];
}

- (NSMutableSet<NSString *> *)enabledBundleIDs {
    id value = CPUthermalReadPrefs()[S("lowPowerApps")];
    return [NSMutableSet setWithArray:[value isKindOfClass:[NSArray class]] ? value : @[]];
}

- (NSArray<NSDictionary *> *)visibleApplications {
    if (!self.allApps) self.allApps = [self enumerateApplications];
    NSString *term = [[self.searchTerm ?: S("") stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] lowercaseString];
    NSMutableArray *visible = [NSMutableArray array];
    for (NSDictionary *app in self.allApps) {
        NSString *name = app[S("name")], *bundleID = app[S("id")];
        if (term.length == 0 || [[name lowercaseString] containsString:term] || [[bundleID lowercaseString] containsString:term]) [visible addObject:app];
    }
    NSSet *enabled = [self enabledBundleIDs];
    [visible sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        BOOL ae = [enabled containsObject:a[S("id")]], be = [enabled containsObject:b[S("id")]];
        if (ae != be) return ae ? NSOrderedAscending : NSOrderedDescending;
        NSComparisonResult r = [a[S("name")] localizedCaseInsensitiveCompare:b[S("name")]];
        return r == NSOrderedSame ? [a[S("id")] compare:b[S("id")]] : r;
    }];
    return visible;
}

- (void)rebuildSpecifiers {
    if (!_specifiers) _specifiers = [[NSMutableArray alloc] init];
    [_specifiers removeAllObjects];
    @try {
        NSArray *apps = [self visibleApplications];
        NSUInteger enabledCount = [self enabledBundleIDs].count;
        PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
        NSString *footer = self.searchTerm.length ? [NSString stringWithFormat:S("找到 %lu 个应用；已开启应用优先显示。"), (unsigned long)apps.count] : [NSString stringWithFormat:S("已指定 %lu 个应用。进入所选应用自动启用低功耗；退至后台后恢复插件对应模式。"), (unsigned long)enabledCount];
        if (!self.allApps.count) footer = S("没有枚举到可用的应用。");
        [group setProperty:footer forKey:S("footerText")];
        [_specifiers addObject:group];
        for (NSDictionary *app in apps) {
            PSSpecifier *specifier = [PSSpecifier preferenceSpecifierNamed:app[S("name")] target:self set:@selector(setAppEnabled:specifier:) get:@selector(appEnabled:) detail:nil cell:PSSwitchCell edit:nil];
            specifier.identifier = app[S("id")];
            [specifier setProperty:app[S("id")] forKey:S("id")];
            [specifier setProperty:app[S("id")] forKey:S("ctBundleID")];
            [specifier setProperty:app[S("path")] ?: S("") forKey:S("ctBundlePath")];
            [_specifiers addObject:specifier];
        }
    } @catch (__unused NSException *exception) {
        [_specifiers removeAllObjects];
        PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
        [group setProperty:S("应用列表加载异常。") forKey:S("footerText")];
        [_specifiers addObject:group];
    }
}

- (NSArray *)specifiers { if (!_specifiers) [self rebuildSpecifiers]; return _specifiers; }
- (id)appEnabled:(PSSpecifier *)specifier { return @([[self enabledBundleIDs] containsObject:specifier.identifier ?: [specifier propertyForKey:S("id")]]); }
- (void)setAppEnabled:(id)value specifier:(PSSpecifier *)specifier {
    NSString *bundleID = specifier.identifier ?: [specifier propertyForKey:S("id")];
    if (bundleID.length == 0) return;
    NSMutableSet *enabled = [self enabledBundleIDs];
    [value boolValue] ? [enabled addObject:bundleID] : [enabled removeObject:bundleID];
    NSMutableDictionary *prefs = CPUthermalReadMutablePrefs() ?: [NSMutableDictionary dictionary];
    prefs[S("lowPowerApps")] = [[enabled allObjects] sortedArrayUsingSelector:@selector(compare:)];
    CPUthermalWritePrefs(prefs);
    notify_post(kCPUthermalSettingsChangedNotifC);
    dispatch_async(dispatch_get_main_queue(), ^{ [self rebuildSpecifiers]; [self.table reloadData]; });
}
- (void)updateSearchResultsForSearchController:(UISearchController *)searchController { self.searchTerm = searchController.searchBar.text ?: S(""); [self rebuildSpecifiers]; [self.table reloadData]; }
@end


#pragma mark - 应用图标

// 从 App 包目录里直接找 png 图标（读 Info.plist 的 CFBundleIconFiles）
static UIImage *CPUthermalIconFromBundle(NSString *bundlePath) {
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[bundlePath stringByAppendingPathComponent:S("Info.plist")]];
    NSMutableArray *bases = [NSMutableArray array];
    id icons = info[S("CFBundleIcons")];
    if ([icons isKindOfClass:[NSDictionary class]]) {
        id primary = icons[S("CFBundlePrimaryIcon")];
        if ([primary isKindOfClass:[NSDictionary class]]) {
            id files = primary[S("CFBundleIconFiles")];
            if ([files isKindOfClass:[NSArray class]]) [bases addObjectsFromArray:files];
        }
    }
    id legacy = info[S("CFBundleIconFiles")];
    if ([legacy isKindOfClass:[NSArray class]]) [bases addObjectsFromArray:legacy];
    [bases addObjectsFromArray:@[S("AppIcon60x60"), S("AppIcon"), S("Icon")]];
    NSFileManager *fm = [NSFileManager defaultManager];
    for (id base in bases) {
        if (![base isKindOfClass:[NSString class]] || [base length] == 0) continue;
        for (NSString *suffix in @[S("@3x.png"), S("@2x.png"), S(".png")]) {
            NSString *file = [[bundlePath stringByAppendingPathComponent:base] stringByAppendingString:suffix];
            if ([fm fileExistsAtPath:file]) {
                UIImage *image = [UIImage imageWithContentsOfFile:file];
                if (image) return image;
            }
        }
    }
    return nil;
}

// 多路取图标：① 私有 API ② LSApplicationProxy.iconData ③ 直接从包内读 png；结果带缓存
static UIImage *CPUthermalIconForApp(NSString *bundleID, NSString *bundlePath) {
    static NSMutableDictionary *cache = nil;
    static NSMutableSet *misses = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ cache = [NSMutableDictionary dictionary]; misses = [NSMutableSet set]; });
    if (bundleID.length == 0) return nil;
    if (cache[bundleID]) return cache[bundleID];
    if ([misses containsObject:bundleID]) return nil;
    UIImage *icon = nil;
    @try {
        CGFloat scale = [UIScreen mainScreen].scale ?: 2.0;
        SEL iconSel = NSSelectorFromString(S("_applicationIconImageForBundleIdentifier:format:scale:"));
        if ([UIImage respondsToSelector:iconSel]) icon = ((UIImage *(*)(id, SEL, NSString *, int, CGFloat))objc_msgSend)([UIImage class], iconSel, bundleID, 0, scale);
        if (!icon) {
            Class proxyClass = objc_getClass("LSApplicationProxy");
            SEL proxySel = NSSelectorFromString(S("applicationProxyForIdentifier:"));
            if (proxyClass && [proxyClass respondsToSelector:proxySel]) {
                id proxy = ((id (*)(id, SEL, NSString *))objc_msgSend)(proxyClass, proxySel, bundleID);
                SEL dataSel = NSSelectorFromString(S("iconData"));
                if (proxy && [proxy respondsToSelector:dataSel]) {
                    NSData *data = ((NSData *(*)(id, SEL))objc_msgSend)(proxy, dataSel);
                    if ([data isKindOfClass:[NSData class]] && data.length) icon = [UIImage imageWithData:data];
                }
            }
        }
        if (!icon && bundlePath.length) icon = CPUthermalIconFromBundle(bundlePath);
    } @catch (__unused NSException *exception) {}
    if (icon) cache[bundleID] = icon; else [misses addObject:bundleID];
    return icon;
}

// 给 Preferences 里的表格行挂图标：运行时替换 PSTableCell 的刷新实现（不用自定义单元格类）
static void (*ct_orig_refresh)(id, SEL, PSSpecifier *) = NULL;

static void ct_refresh_cell(id self, SEL _cmd, PSSpecifier *specifier) {
    if (ct_orig_refresh) ct_orig_refresh(self, _cmd, specifier);
    @try {
        NSString *bundleID = [specifier propertyForKey:S("ctBundleID")];
        if (bundleID.length == 0) return;
        UIImage *icon = CPUthermalIconForApp(bundleID, [specifier propertyForKey:S("ctBundlePath")]);
        if (!icon) return;
        UITableViewCell *cell = (UITableViewCell *)self;
        cell.imageView.image = icon;
        cell.imageView.contentMode = UIViewContentModeScaleAspectFit;
    } @catch (__unused NSException *exception) {}
}

__attribute__((constructor)) static void ct_install_cell_icon_hook(void) {
    Class cellClass = NSClassFromString(S("PSTableCell"));
    SEL sel = NSSelectorFromString(S("refreshCellContentsWithSpecifier:"));
    if (!cellClass) return;
    Method method = class_getInstanceMethod(cellClass, sel);
    if (!method) return;
    ct_orig_refresh = (void (*)(id, SEL, PSSpecifier *))method_getImplementation(method);
    method_setImplementation(method, (IMP)ct_refresh_cell);
}
