#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <notify.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <CPUthermalPaths.h>

static NSString *CPUthermalOwnBundleID(void) {
    return [[NSBundle mainBundle] bundleIdentifier];
}

static NSString *CPUthermalStringFromObject(id object, const char **selectors) {
    for (int i = 0; object && selectors[i]; i++) {
        SEL selector = sel_registerName(selectors[i]);
        if (![object respondsToSelector:selector]) continue;
        id value = ((id (*)(id, SEL))objc_msgSend)(object, selector);
        if ([value isKindOfClass:[NSString class]] && [value length] > 0) return value;
    }
    return nil;
}

static void CPUthermalReportCurrentApplication(void) {
    UIApplication *application = [UIApplication sharedApplication];
    if (application.applicationState != UIApplicationStateActive) return;
    CPUthermalPostForegroundBundleID(CPUthermalOwnBundleID());
}

static void CPUthermalClearCurrentApplication(void) {
    CPUthermalClearForegroundBundleIDIfCurrent(CPUthermalOwnBundleID());
}

// ─────────────────────────────────────────────────────────────
// 真值源：SBApplication 的 activate / deactivate 事件
// 私有接口 _accessibilityFrontMostApplication 在 iOS 17 上对全屏应用
// （抖音/直播间等）经常返回 nil，或返回"上一个 App"/SpringBoard。
// 只要采信它，就会在"从后台卡片直接切进指定 App"时上报错误的 bundleID
// → thermalmonitord 侧哈希对不上 → 立刻撤销低功耗（= 变满频）。
// 所以：activate 钩子记录下来的 App 才是权威值，轮询只作兜底。
// ─────────────────────────────────────────────────────────────
static NSString *g_trackedFrontmostBundleID = nil;   // 最近一次被 activate 的 App
static CFAbsoluteTime g_trackedAt = 0;               // 该次 activate 的时间
static CFAbsoluteTime g_trackedDeactivatedAt = 0;    // 该 App 最近一次 deactivate 的时间
static CFAbsoluteTime g_pollDisagreeSince = 0;       // 私有接口持续指向别的 App 的起点

// 仅在"该 App 已经 deactivate 超过 3 秒"后失效；不再用固定 TTL：
// 直播间/长时间停留在目标 App 内时，钩子记录必须一直有效。
static NSString *CPUthermalTrackedFrontmostBundleID(void) {
    if (!g_trackedFrontmostBundleID.length) return nil;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (g_trackedDeactivatedAt > 0 && (now - g_trackedDeactivatedAt) > 3.0) return nil;
    return g_trackedFrontmostBundleID;
}

// 原始私有接口（取不到就返回 nil，不再内部兜底，交给轮询逻辑判断）
static NSString *CPUthermalSpringBoardFrontmostBundleID(void) {
    id springBoard = [UIApplication sharedApplication];
    id application = nil;
    const char *frontSelectors[] = {"_accessibilityFrontMostApplication", "accessibilityFrontMostApplication", "frontmostApplication", NULL};
    for (int i = 0; frontSelectors[i] && !application; i++) {
        SEL selector = sel_registerName(frontSelectors[i]);
        if ([springBoard respondsToSelector:selector]) application = ((id (*)(id, SEL))objc_msgSend)(springBoard, selector);
    }
    if (!application) {
        Class controllerClass = objc_getClass("SBApplicationController");
        SEL sharedSelector = sel_registerName("sharedInstance");
        id controller = [controllerClass respondsToSelector:sharedSelector] ? ((id (*)(id, SEL))objc_msgSend)(controllerClass, sharedSelector) : nil;
        SEL frontSelector = sel_registerName("frontmostApplication");
        if ([controller respondsToSelector:frontSelector]) application = ((id (*)(id, SEL))objc_msgSend)(controller, frontSelector);
    }
    if (!application) {
        // 再兜一层：SBWorkspace 在部分系统版本上持有前台应用。
        Class workspaceClass = objc_getClass("SBWorkspace");
        SEL mainSelector = sel_registerName("mainWorkspace");
        id workspace = [workspaceClass respondsToSelector:mainSelector] ? ((id (*)(id, SEL))objc_msgSend)(workspaceClass, mainSelector) : nil;
        SEL frontSelector = sel_registerName("frontmostApplication");
        if ([workspace respondsToSelector:frontSelector]) application = ((id (*)(id, SEL))objc_msgSend)(workspace, frontSelector);
    }
    const char *idSelectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    return CPUthermalStringFromObject(application, idSelectors);
}

// ── 直播间/辅助进程归一化 ──
// 进直播间时前台会变成辅助进程（bundleID = 目标App + ".xxx"），
// 用它去比对配置项哈希必然失败 → 掉低功耗。
// 归一化回"最近激活的那个 App"（只用原文件已有的 NSString 方法，不引入新符号）。
// 注意：这里用不带有效期的原始值，直播间可以持续很久。
static NSString *CPUthermalNormalizeBundleID(NSString *bundleID) {
    NSString *tracked = g_trackedFrontmostBundleID;
    if (!bundleID.length || !tracked.length) return bundleID;
    if (bundleID.length > tracked.length && [bundleID hasPrefix:tracked] &&
        [bundleID characterAtIndex:tracked.length] == '.') return tracked;
    return bundleID;
}

// 判断两个 bundleID 是否属于"同一个应用"（主 App 与其辅助进程互为前缀+点）。
static BOOL CPUthermalSameApplication(NSString *a, NSString *b) {
    if (!a.length || !b.length) return NO;
    if ([a isEqualToString:b]) return YES;
    if (a.length > b.length) return ([a hasPrefix:b] && [a characterAtIndex:b.length] == '.');
    return ([b hasPrefix:a] && [b characterAtIndex:a.length] == '.');
}

// 进直播间/新版本 App 会以 <主App>.xxx 的辅助进程单独 activate，
// 直接把它记成"当前 App"会让配置项哈希对不上 → 一律归并到更短的主 App。
static NSString *CPUthermalCanonicalBundleID(NSString *bundleID) {
    NSString *prev = g_trackedFrontmostBundleID;
    if (!bundleID.length || !prev.length) return bundleID;
    if (!CPUthermalSameApplication(bundleID, prev)) return bundleID;
    return (bundleID.length <= prev.length) ? bundleID : prev;
}

static void CPUthermalReportForegroundBundleID(NSString *bundleID) {
    CPUthermalPostForegroundBundleID(CPUthermalNormalizeBundleID(bundleID));
}

static void CPUthermalStartSpringBoardMonitor(void) {
    __block uint64_t lastHash = UINT64_MAX;
    __block CFAbsoluteTime lastPost = 0;
    void (^poll)(void) = ^{
        CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
        NSString *polled = CPUthermalSpringBoardFrontmostBundleID();
        // SpringBoard 自己不算"前台 App"（卡片切换/转场时会短暂返回它）
        if ([polled isEqualToString:S("com.apple.springboard")]) polled = nil;
        NSString *tracked = CPUthermalTrackedFrontmostBundleID();
        NSString *effective = polled;
        if (tracked.length) {
            if (polled.length && [polled isEqualToString:tracked]) {
                g_pollDisagreeSince = 0;
            } else if (!polled.length) {
                // 私有接口取不到（全屏应用/转场）→ 以刚激活的 App 为准，绝不退回上一个 App
                effective = tracked;
                g_pollDisagreeSince = 0;
            } else if ((now - g_trackedAt) <= 3.0) {
                // 切换后 3 秒内接口常返回"上一个 App"→ 仍以刚激活的 App 为准
                effective = tracked;
                g_pollDisagreeSince = 0;
            } else {
                // 持续 10 秒都指向别的 App：视为钩子漏掉了 deactivate，改口采信接口值
                if (g_pollDisagreeSince <= 0) g_pollDisagreeSince = now;
                if ((now - g_pollDisagreeSince) >= 10.0) {
                    g_trackedFrontmostBundleID = nil;
                    g_trackedDeactivatedAt = 0;
                    g_pollDisagreeSince = 0;
                    effective = polled;
                } else {
                    effective = tracked;
                }
            }
        }
        if (!effective.length) {
            // 钩子与私有接口都确认没有前台应用（回桌面/真退出）：1.5 秒后上报"无应用"
            if (CPUthermalReadForegroundBundleHash() != 0 && (now - lastPost) >= 1.5) {
                lastHash = 0;
                lastPost = now;
                CPUthermalReportForegroundBundleID(nil);
            }
            return;
        }
        uint64_t hash = CPUthermalBundleIDHash(effective);
        uint64_t current = CPUthermalReadForegroundBundleHash();
        // 哈希变化立即上报；哈希不变时每 2 秒心跳重发一次；若通知状态被
        // App 侧/辅助进程改成了别的哈希（直播间等），下一次轮询立刻纠正。
        if (hash == lastHash && hash == current && (now - lastPost) < 2.0) return;
        lastHash = hash;
        lastPost = now;
        CPUthermalReportForegroundBundleID(effective);
    };
    poll();
    // 100ms 兜底轮询；应用激活 Hook 仍是主路径，RootHide 阻止目标 App 注入时也能快速识别。
    [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(__unused NSTimer *timer) { poll(); }];
}

@interface SBApplication : NSObject
- (NSString *)bundleIdentifier;
- (NSString *)displayIdentifier;
@end

%hook SBApplication
- (void)activate {
    const char *selectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    NSString *bundleID = CPUthermalStringFromObject(self, selectors);
    // 辅助进程（直播间/扩展）activate 时归并回主 App，避免把配置项哈希冲掉。
    if (bundleID.length) bundleID = CPUthermalCanonicalBundleID(bundleID);
    if (bundleID.length) {
        g_trackedFrontmostBundleID = bundleID;
        g_trackedAt = CFAbsoluteTimeGetCurrent();
        g_trackedDeactivatedAt = 0;      // 重新激活 → 重新生效
        g_pollDisagreeSince = 0;
    }
    // activate 前先发布，thermalmonitord 可与应用前台切换并行套用低功耗；完成后再确认一次。
    if (bundleID.length) CPUthermalReportForegroundBundleID(bundleID);
    %orig;
    if (bundleID.length) CPUthermalReportForegroundBundleID(bundleID);
}
- (void)deactivate {
    // 这里只"打标记"，不清状态、不上报 0：
    // 从后台卡片直接切进目标 App 时 deactivate(旧App) 与 activate(新App) 之间
    // 会短暂取不到前台应用，旧逻辑一清就把刚生效的低功耗打掉 → 变满频。
    const char *selectors[] = {"bundleIdentifier", "displayIdentifier", "applicationIdentifier", NULL};
    NSString *bundleID = CPUthermalStringFromObject(self, selectors);
    // 主 App 的辅助进程 deactivate 同样视为"离开该 App"（否则会一直粘住）。
    if (CPUthermalSameApplication(bundleID, g_trackedFrontmostBundleID)) {
        g_trackedDeactivatedAt = CFAbsoluteTimeGetCurrent();
    }
    %orig;
}
%end

%hook UIApplication
- (void)didBecomeActive {
    %orig;
    if (![CPUthermalOwnBundleID() isEqualToString:S("com.apple.springboard")]) CPUthermalReportCurrentApplication();
}
- (void)didEnterBackground {
    %orig;
    // 本进程真的退到后台：只清除"自己"这一条（当前值不是自己就不动），
    // 避免和 SpringBoard 侧的轮询互相覆盖。
    CPUthermalClearCurrentApplication();
}
%end

%ctor {
    @autoreleasepool {
        NSString *ownBundleID = CPUthermalOwnBundleID();
        // 诊断：确认本进程是否真的载入 CPUthermalForeground.dylib（判定过滤器是否命中）。
        NSLog(S("[CPUthermal] Foreground 载入 proc=%@ bundle=%@"), [[NSProcessInfo processInfo] processName], ownBundleID);
        dispatch_async(dispatch_get_main_queue(), ^{
            if ([ownBundleID isEqualToString:S("com.apple.springboard")]) {
                CPUthermalStartSpringBoardMonitor();
                NSLog(S("[CPUthermal] SpringBoard 前台监控已启动"));
                return;
            }
            NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
            [center addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) { CPUthermalReportCurrentApplication(); }];
            [center addObserverForName:UIApplicationWillEnterForegroundNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) {
                dispatch_async(dispatch_get_main_queue(), ^{ CPUthermalReportCurrentApplication(); });
            }];
            [center addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(__unused NSNotification *note) { CPUthermalClearCurrentApplication(); }];
            CPUthermalReportCurrentApplication();
        });
    }
}
